import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
public class AdminPanel
{ 
	 //private DrawingArea draw;
	   static private JButton b1, b2;
	   private JPanel userInt;
	   private JSpinner gravitySpinner;
	   int secondsToWait = 500;
	   private JPanel mainPanel = new JPanel();
	   
	   private JLabel positionLabel;
	    private JButton resetButton;
	    private static int gridSize = 5;
	    private static JButton [][]tab_button=new JButton[gridSize][gridSize];
	    int ctr=0;
	    Connection con=null;
	    ArrayList<String> al=new ArrayList<String>();
	    static ArrayList<String> al1=new ArrayList<String>();
	AdminPanel() {
		try{
		Connection con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
		Statement s=con.createStatement();
		 ResultSet result_set1=s.executeQuery("select TABLE_NO from waiter where TABLE_NO!=''");
		 while(result_set1.next())
	        {
			 al1.add(result_set1.getString(1));				
	        }
		}catch(Exception ee){
			System.out.println(ee);
		}
		int size=al.size();
		mainPanel.setLayout(null);
		mainPanel.setVisible(true);
		mainPanel.setFont(new Font("Dialog", Font.PLAIN, 22));

		JLabel title=new JLabel("SUKHDEV VAISHNO DHABA");
		title.setFont(new Font("Italianate", Font.BOLD, 30));
		title.setBounds(550,20,1000,80);
		
		title.setAlignmentX(1000);
		title.setAlignmentY(1000);
		int counter = 0;
		mainPanel.add(title);
	
		/*JButton stock =new JButton("Make Order");
		MakeOrder s=new MakeOrder();
		stock.setBounds(30,180,230,50);
		stock.addActionListener(s);
		stock.setForeground(Color.white);
		stock.setFont(new Font("NIAGARA SOLID", Font.BOLD, 30));
		stock.setBackground(new Color(255,69,0));
		mainPanel.add(stock);
		*/
		JButton supplier =new JButton("Report");
		Report ss=new Report();
		supplier.setBounds(30,180,230,50);
		
		supplier.addActionListener(ss);
		mainPanel.add(supplier);
		
		JButton customer =new JButton("Business Analysis");
		BA cc=new BA();
		customer.setBounds(30,280,230,50);
		
		customer.addActionListener(cc);
		mainPanel.add(customer);
		
		JButton spurchase =new JButton("Waiter Analysis");
		WA pp=new WA();
		spurchase.setBounds(30,380,230,50);
		
		spurchase.addActionListener(pp);
		
		mainPanel.add(spurchase);
		
		JButton foodb =new JButton("Food");
		Food food=new Food();
		foodb.setBounds(30,480,230,50);
		foodb.addActionListener(food);
	
		mainPanel.add(foodb);
		
		
		
		
		JPanel images=new JPanel();
		images.setBounds(300,125,1050,600);
		
		images.setLayout(new GridLayout(gridSize, gridSize, 10, 10));
		mainPanel.add(images);
		
		
	        for (int i = 0; i < gridSize; i++)
	        {
	            for (int j = 0; j < gridSize; j++)
	            {
	            
	            	ctr=ctr+1;
	            	//System.out.println(ctr);
	                 tab_button[i][j] = new JButton("Table "+ctr);
	                 if(al1.contains(tab_button[i][j].getText())){
	                	 tab_button[i][j].setBackground(Color.red);
	                 }
	                 
	              	                
	               // tab_button[i][j] .setActionCommand("(" + i + ", " + j + ")");
	                //tab_button[i][j].addActionListener(new MakeOrder());
	                
	                images.add(tab_button[i][j] );
	            }
	        }
	        tab_button[0][0] .addActionListener(new MakeOrder());
	        tab_button[0][1] .addActionListener(new MakeOrder2());
	        tab_button[0][2] .addActionListener(new MakeOrder3());
	        tab_button[0][3] .addActionListener(new MakeOrder4());
	        tab_button[0][4] .addActionListener(new MakeOrder5());
	        
	        tab_button[1][0] .addActionListener(new MakeOrder6());
	        tab_button[1][1] .addActionListener(new MakeOrder7());
	        tab_button[1][2] .addActionListener(new MakeOrder8());
	        tab_button[1][3] .addActionListener(new MakeOrder9());
	        tab_button[1][4] .addActionListener(new MakeOrder10());
	        
	        tab_button[2][0] .addActionListener(new MakeOrder11());
	        tab_button[2][1] .addActionListener(new MakeOrder12());
	        tab_button[2][2] .addActionListener(new MakeOrder13());
	        tab_button[2][3] .addActionListener(new MakeOrder14());
	        tab_button[2][4] .addActionListener(new MakeOrder15());
	        
	        tab_button[3][0] .addActionListener(new MakeOrder16());
	        tab_button[3][1] .addActionListener(new MakeOrder17());
	        tab_button[3][2] .addActionListener(new MakeOrder18());
	        tab_button[3][3] .addActionListener(new MakeOrder19());
	        tab_button[3][4] .addActionListener(new MakeOrder20());
	        
	        tab_button[4][0] .addActionListener(new MakeOrder21());
	        tab_button[4][1] .addActionListener(new MakeOrder22());
	        tab_button[4][2] .addActionListener(new MakeOrder23());
	        tab_button[4][3] .addActionListener(new MakeOrder24());
	        tab_button[4][4] .addActionListener(new MakeOrder25());
	        MainUI.window.dispose();
	}
	
	
	public JPanel getMainPanel() {
	      return mainPanel;
	   }
	

	}

