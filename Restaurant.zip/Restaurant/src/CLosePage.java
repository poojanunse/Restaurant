import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;




public class CLosePage implements ActionListener {

	public void actionPerformed(ActionEvent ae){
		
		if(ae.getSource()==MakeOrder.back){
			new MainUI();
		MakeOrder.frame1.setVisible(false);
		MakeOrder.frame1.dispose();
		}
	
		if(ae.getSource()==MakeOrder2.back){
			new MainUI();
			MakeOrder2.frame1.setVisible(false);
			MakeOrder2.frame1.dispose();
			}
	
		if(ae.getSource()==MakeOrder3.back){
			new MainUI();
			MakeOrder3.frame1.setVisible(false);
			MakeOrder3.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder4.back){
			new MainUI();
			MakeOrder4.frame1.setVisible(false);
			MakeOrder4.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder5.back){
			new MainUI();
			MakeOrder5.frame1.setVisible(false);
			MakeOrder5.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder6.back){
			new MainUI();
			MakeOrder6.frame1.setVisible(false);
			MakeOrder6.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder7.back){
			new MainUI();
			MakeOrder7.frame1.setVisible(false);
			MakeOrder7.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder8.back){
			new MainUI();
			MakeOrder8.frame1.setVisible(false);
			MakeOrder8.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder9.back){
			new MainUI();
			MakeOrder9.frame1.setVisible(false);
			MakeOrder9.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder10.back){
			new MainUI();
			MakeOrder10.frame1.setVisible(false);
			MakeOrder10.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder11.back){
			new MainUI();
			MakeOrder11.frame1.setVisible(false);
			MakeOrder11.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder12.back){
			new MainUI();
			MakeOrder12.frame1.setVisible(false);
			MakeOrder12.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder13.back){
			new MainUI();
			MakeOrder13.frame1.setVisible(false);
			MakeOrder13.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder14.back){
			new MainUI();
			MakeOrder14.frame1.setVisible(false);
			MakeOrder14.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder15.back){
			new MainUI();
			MakeOrder15.frame1.setVisible(false);
			MakeOrder15.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder16.back){
			new MainUI();
			MakeOrder16.frame1.setVisible(false);
			MakeOrder16.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder17.back){
			new MainUI();
			MakeOrder17.frame1.setVisible(false);
			MakeOrder17.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder18.back){
			new MainUI();
			MakeOrder18.frame1.setVisible(false);
			MakeOrder18.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder19.back){
			new MainUI();
			MakeOrder19.frame1.setVisible(false);
			MakeOrder19.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder20.back){
			new MainUI();
			MakeOrder20.frame1.setVisible(false);
			MakeOrder20.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder21.back){
			new MainUI();
			MakeOrder21.frame1.setVisible(false);
			MakeOrder21.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder22.back){
			new MainUI();
			MakeOrder22.frame1.setVisible(false);
			MakeOrder22.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder23.back){
			new MainUI();
			MakeOrder23.frame1.setVisible(false);
			MakeOrder23.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder24.back){
			new MainUI();
			MakeOrder24.frame1.setVisible(false);
			MakeOrder24.frame1.dispose();
			}
		if(ae.getSource()==MakeOrder25.back){
			new MainUI();
			MakeOrder25.frame1.setVisible(false);
			MakeOrder25.frame1.dispose();
			}
		
		if(ae.getSource()==Food.back){
		new MainUI();
			Food.frame.dispose();
		
		}
		if(ae.getSource()==WA.back){
			new MainUI();
				WA.frame.dispose();
			
			}
		if(ae.getSource()==Food.back){
			new MainUI();
				Food.frame.dispose();
			
			}
		if(ae.getSource()==BA.back){
			new MainUI();
				BA.frame.dispose();
			
			}
		if(ae.getSource()==Report.Reportck){
			new MainUI();
				Report.frame.dispose();
			
			}
	}
	
}
