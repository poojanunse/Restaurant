import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;


public class MainUI {
	 static JFrame window;
public static void main(String args[]){
	 
	SwingUtilities.invokeLater(new Runnable() {
         public void run() {
           window = new JFrame("Welcome to Restaurant");
            window.add(new AdminPanel().getMainPanel());
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            window.pack();
            window.setSize(2000,2000);
            window.setLocationRelativeTo(null);
            window.setVisible(true);
           
         }
      });
}	
}
