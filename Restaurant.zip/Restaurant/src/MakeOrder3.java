import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class MakeOrder3 implements  ActionListener{

	static JButton btnsubmit,back,bill,add;
	static JTextField gst1,gsts,txtInput;
	 static JTextField stockName1;
	 static JTextField pp,tot1;
	  static JTextField qty1,service1;
	  static JTextField date1,wtr1,pay1;
	  static JFrame frame1;
	  static JPanel panel;
	  static JLabel status;
	  static double val1,val2,payment;
	  ArrayList<String> items = new ArrayList<String>();
	  private JLabel positionLabel;
	    private JButton resetButton,tab_button;
	    private static int gridSize = 4;
	    String waiter_qry="";
	   Connection con=null;
	 String[] columnNames = {"ID","Date","Topic", "Message"};
	 static int i=0;
	 static String tab_no="";
	
		
	@Override
	public void actionPerformed(ActionEvent ae) {
		  frame1=new JFrame();
			 JPanel p=new JPanel();
			 p.setBounds(800,800,20,20);
			 p.setBackground(Color.black);
			 frame1.add(p);
			  frame1.setVisible(true);
			   
				 frame1.setLayout(null);
				 frame1.setSize(1500,1500);
		int ctr=0;
		           		 frame1.getContentPane().setBackground(Color.white);
	               		 frame1.setTitle("Welcome to My Restaurant");
	               		
	               		 JLabel status1=new JLabel("Make Order");
	        			 status1.setBounds(100,40,250,60);
	        			
	        			 frame1.add(status1);
	        			 tab_no=((AbstractButton) ae.getSource()).getText();
	        			 System.out.println(tab_no);
	                       System.out.println("Button clicked"+((AbstractButton) ae.getSource()).getText());
	                   	 
	                       JLabel table=new JLabel(tab_no);
		               		table.setBounds(250,40,250,60);
		               		
		        			 frame1.add(table);
		               		 
	                       
	                       JLabel stockName=new JLabel("Customer Name");
	              		 stockName.setBounds(70,90,150,60);
	              		frame1.add(stockName);
	              		 stockName1 =new JTextField();
	              		 stockName1.setBounds(250,110,150,20);
	              		frame1.add(stockName1);
	              		 
	              		
	              		
	              		 JLabel um=new JLabel("Select Food");
	              		 um.setBounds(70,130,150,60);
	              		frame1.add(um);
	              	   txtInput = new JTextField();
	              		
	              		
	              		 String waiter = null;
	              		 
	              		 
					
	              		try{
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from food";
	           			waiter_qry="select * from waiter where TABLE_NO='"+((AbstractButton) ae.getSource()).getText()+"'";
	           			 Statement st=con.createStatement();
	        			 Statement statement=con.createStatement();
	        			
	        			 ResultSet result_set1=st.executeQuery(waiter_qry);
	        			
	        			while(result_set1.next())
		     		        {
	        				waiter=result_set1.getString(2);
		     					System.out.println("waiter"+waiter);
		     					
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
	            		
	              		
	              		 
	              		  JLabel l3=new JLabel("Price");
	              		  l3.setBounds(70,170,150,60);
	              		frame1.add(l3);
	              		   pp =new JTextField();
	              		  pp.setBounds(250,190,150,20);
	              		pp.setEditable(false);
	              		frame1.add(pp);
	              		  
	              		  JLabel qty=new JLabel("Quantity");
	              		  qty.setBounds(70,220,150,60);
	              		frame1.add(qty);
	              		qty1 =new JTextField();
	              		  qty1.setBounds(250,230,150,20);
	              		frame1.add(qty1);
	              		qty1.getDocument().addDocumentListener(new DocumentListener(){

							@Override
							public void insertUpdate(DocumentEvent e) {
								// TODO Auto-generated method stub
								warn();
							}

							@Override
							public void removeUpdate(DocumentEvent e) {
								// TODO Auto-generated method stub
								warn();
							}

							@Override
							public void changedUpdate(DocumentEvent e) {
								// TODO Auto-generated method stub
								warn();
							}
							public void warn(){
								pp.setText((MakeOrder3.getInt(pp))*(MakeOrder3.getInt(qty1))+"");
			              		System.out.println((MakeOrder3.getInt(pp)));
			              		System.out.println((MakeOrder3.getInt(qty1))+"");
							}
	              			
	              		});
	              		  
	              		  JLabel date=new JLabel("Date");
	              		  date.setBounds(70,260,150,60);
	              		frame1.add(date);
	              		  Calendar now = Calendar.getInstance();
	                          int month = now.get(Calendar.MONTH);
	                          int day = now.get(Calendar.DAY_OF_MONTH);
	                          int year = now.get(Calendar.YEAR);
	                          
	              		 date1 =new JTextField();
	              		  date1.setBounds(250,270,150,20);
	              		date1.setEditable(false);
	              		 // date1.setText("" + (month + 1) + "/" + day + "/" + year);
	              		  date1.setText("" + year + "-" + (month+1) + "-" + day);
	              		frame1.add(date1);
	              		  
	              		 JLabel wtr=new JLabel("Waiter");
	              		wtr.setBounds(70,390,150,60);
	              		frame1.add(wtr);
	              		wtr1 =new JTextField();
	              		wtr1.setBounds(250,400,150,20);
	              		wtr1.setText(waiter);
	              		wtr1.setEditable(false);
	              		frame1.add(wtr1);
	              		
	              		
	              		 JLabel gst=new JLabel("CGST %");
		              		gst.setBounds(420,410,50,60);
			              		frame1.add(gst);
			              		gst1 =new JTextField();
			              		gst1.setBounds(460,430,50,20);
			              		
			              		frame1.add(gst1);
			              		gst1.getDocument().addDocumentListener(new DocumentListener(){

									@Override
									public void insertUpdate(DocumentEvent e) {
										// TODO Auto-generated method stub
										warn();
									}

									@Override
									public void removeUpdate(DocumentEvent e) {
										// TODO Auto-generated method stub
										warn();
									}

									@Override
									public void changedUpdate(DocumentEvent e) {
										// TODO Auto-generated method stub
										warn();
									}
									public void warn(){
										double gst=MakeOrder3.getDouble(gst1)/100;
										int price=MakeOrder3.getInt(tot1);
										System.out.println(gst+"SF");
										System.out.println(price+"SF");
										System.out.println(price+"SF");
										 val1=(gst*price);
										//service1.setText(val+"");
										
									}
			              			
			              		});
			              		
			              		 JLabel sgst=new JLabel("SGST %");
				              		sgst.setBounds(570,410,50,60);
					              		frame1.add(sgst);
					              		gsts =new JTextField();
					              		gsts.setBounds(610,430,50,20);
					              		
					              		frame1.add(gsts);
					              		gsts.getDocument().addDocumentListener(new DocumentListener(){

											@Override
											public void insertUpdate(DocumentEvent e) {
												// TODO Auto-generated method stub
												warn();
											}

											@Override
											public void removeUpdate(DocumentEvent e) {
												// TODO Auto-generated method stub
												warn();
											}

											@Override
											public void changedUpdate(DocumentEvent e) {
												// TODO Auto-generated method stub
												warn();
											}
											public void warn(){
												double gst=MakeOrder3.getDouble(gsts)/100;
												int price=MakeOrder3.getInt(tot1);
												System.out.println(gst+"SF");
												System.out.println(price+"SF");
												System.out.println(price+"SF");
												val2=(gst*price);
												service1.setText(MakeOrder3.val1+MakeOrder3.val2+"");
												  payment=MakeOrder3.getDouble(service1)+MakeOrder3.getDouble(tot1);
													System.out.println("sjkj"+payment);
													pay1.setText(payment+"");
											}
					              			
					              		});
					              		
			              		
	              		 JLabel service=new JLabel("Service Charge");
	              		service.setBounds(70,420,150,60);
		              		frame1.add(service);
		              		service1 =new JTextField();
		              		service1.setBounds(250,430,150,20);
		              		service1.setEditable(false);
		              		frame1.add(service1);
		              		
		              		 JLabel pay=new JLabel("Payable Amount");
		              		pay.setBounds(70,450,150,60);
				             frame1.add(pay);
				             pay1 =new JTextField();
				             pay1.setBounds(250,460,150,20);
				             pay1.setEditable(false);
				             frame1.add(pay1);
				              		
				             add=new JButton("Add");
		              		 Database db=new Database();
		              		add.setBounds(450,150,100,20);
		              		add.addActionListener(db);
		              		
		              			frame1.add(add);
				             
		              			 JLabel tot=new JLabel("Total Amount");
				              		tot.setBounds(70,360,150,60);
						             frame1.add(tot);
						             tot1 =new JTextField();
						             tot1.setBounds(250,370,150,20);
						             tot1.setEditable(false);
						             frame1.add(tot1);
				            
	              		 btnsubmit=new JButton("Get Total");
	              		  db=new Database();
	              		  btnsubmit.setBounds(150,320,150,30);
	              		  btnsubmit.addActionListener(db);
	              		  
	              			frame1.add(btnsubmit);
	              		  
	              		  back=new JButton("BACK");
	              		CLosePage pp=new CLosePage();
	              
	              			  back.setBounds(350,530,150,30);
	              			
	              			  back.addActionListener(pp);
	              			frame1.add(back);
	              			  
	              		  bill=new JButton("Generate Bill");
	              			 GenerateBill gb=new GenerateBill();
	              			bill.setBounds(100,530,200,30);
	              		
	              			bill.addActionListener(gb);
	              			frame1.add(bill);
	              			
	              		
	              			
	              			
	              		       
		// TODO Auto-generated method stub
		  try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	        
	       

	        ArrayList<String> items = new ArrayList<String>();
	        try{
      			 Class.forName("org.sqlite.JDBC");
      			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
      			 System.out.println("SQLite3 Connection Established ...");
      			 String query="select * from food";
      			
      			 Statement st=con.createStatement();
   			 Statement statement=con.createStatement();
   			 ResultSet result_set=statement.executeQuery(query);
   			
   			
   			 while(result_set.next())
		        {
					System.out.println(result_set.getString("DISH_NAME"));
					items.add(result_set.getString("DISH_NAME"));
					//System.out.println("price"+result_set.getString("PRICE"));
					//pp.setText(result_set.getString("PRICE"));
		        }
   			
         		}catch(Exception ex){
       			ex.printStackTrace();
       		}
	       
	       
	      
	        setupAutoComplete(txtInput, items);
	        txtInput.setColumns(30);
	        txtInput.setBounds(250,150,150,20);
	        frame1.getContentPane().setLayout(null);
	       frame1.getContentPane().add(txtInput, BorderLayout.NORTH);
	        frame1.setVisible(true);
	    }

	    private static boolean isAdjusting(JComboBox cbInput) {
	        if (cbInput.getClientProperty("is_adjusting") instanceof Boolean) {
	            return (Boolean) cbInput.getClientProperty("is_adjusting");
	        }
	        return false;
	    }
	    
	       static Integer getInt(JTextField gst12){
	    	   Integer var;
	    	   if(gst12.getText().trim().equals("")){
	    		   var=0;
	    	   }else{
	    		   var=Integer.parseInt(gst12.getText());
	    	   }
	    	   return var;
	       }
	       static Double getDouble(JTextField gst12){
	    	   double var;
	    	   if(gst12.getText().trim().equals("")){
	    		   var=0;
	    	   }else{
	    		   var=Double.parseDouble(gst12.getText());
	    	   }
	    	   return var;
	       }

	       



	
	   private static void setAdjusting(JComboBox cbInput, boolean adjusting) {
	        cbInput.putClientProperty("is_adjusting", adjusting);
	    }

	    public static void setupAutoComplete(final JTextField txtInput, final ArrayList<String> items) {
	        final DefaultComboBoxModel model = new DefaultComboBoxModel();
	        final JComboBox cbInput = new JComboBox(model) {
	            public Dimension getPreferredSize() {
	                return new Dimension(super.getPreferredSize().width, 0);
	            }
	        };
	        setAdjusting(cbInput, false);
	        for (String item : items) {
	            model.addElement(item);
	        }
	        cbInput.setSelectedItem(null);
	        cbInput.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            
	                if (!isAdjusting(cbInput)) {
	                    if (cbInput.getSelectedItem() != null) {
	                        txtInput.setText(cbInput.getSelectedItem().toString());
	                        System.out.println("Dish Choosen"+cbInput.getSelectedItem().toString());
	                        try{
	                 			 Class.forName("org.sqlite.JDBC");
	                 			 Connection con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	                 			 System.out.println("SQLite3 Connection Established ...");
	                 			 String query="select * from food where DISH_NAME='"+cbInput.getSelectedItem().toString()+"'";
	                 			
	                 			 Statement st=con.createStatement();
	              			 Statement statement=con.createStatement();
	              			 ResultSet result_set=statement.executeQuery(query);
	              			 while(result_set.next())
	         		        {
	         					
	         					System.out.println("price"+result_set.getString("PRICE"));
	         					pp.setText(result_set.getString("PRICE"));
	         		        }
	                        }catch(Exception ee){
	                        	System.out.println(ee);
	                        }
	                    }
	                }
	            }
	        });

	        txtInput.addKeyListener(new KeyAdapter() {

	            @Override
	            public void keyPressed(KeyEvent e) {
	                setAdjusting(cbInput, true);
	                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
	                    if (cbInput.isPopupVisible()) {
	                        e.setKeyCode(KeyEvent.VK_ENTER);
	                    }
	                }
	                if (e.getKeyCode() == KeyEvent.VK_ENTER || e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN) {
	                    e.setSource(cbInput);
	                    cbInput.dispatchEvent(e);
	                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
	                        txtInput.setText(cbInput.getSelectedItem().toString());
	                        cbInput.setPopupVisible(false);
	                    }
	                }
	                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
	                    cbInput.setPopupVisible(false);
	                }
	                setAdjusting(cbInput, false);
	            }
	        });
	        txtInput.getDocument().addDocumentListener(new DocumentListener() {
	            public void insertUpdate(DocumentEvent e) {
	                updateList();
	            }

	            public void removeUpdate(DocumentEvent e) {
	                updateList();
	            }

	            public void changedUpdate(DocumentEvent e) {
	                updateList();
	            }

	            private void updateList() {
	                setAdjusting(cbInput, true);
	                model.removeAllElements();
	                String input = txtInput.getText();
	                if (!input.isEmpty()) {
	                    for (String item : items) {
	                        if (item.toLowerCase().startsWith(input.toLowerCase())) {
	                            model.addElement(item);
	                        }
	                    }
	                }
	                cbInput.setPopupVisible(model.getSize() > 0);
	                setAdjusting(cbInput, false);
	            }
	        });
	        txtInput.setLayout(new BorderLayout());
	        txtInput.add(cbInput, BorderLayout.SOUTH);
	}
}


 /*class CheckBoxInList implements ActionListener{
	   

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 JFrame frame = new JFrame();
	      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      JList list = new JList(new CheckListItem[] {
	            new CheckListItem("1"),
	            new CheckListItem("2"),
	            new CheckListItem("3"),
	            new CheckListItem("4"),
	            new CheckListItem("5")});

	      list.setCellRenderer(new CheckListRenderer());
	      list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	      list.addMouseListener(new MouseAdapter(){
	         public void mouseClicked(MouseEvent event){
	            JList list = (JList) event.getSource();
	            int index = list.locationToIndex(event.getPoint());
	            CheckListItem item = (CheckListItem)
	               list.getModel().getElementAt(index);
	            item.setSelected(! item.isSelected());
	            list.repaint(list.getCellBounds(index, index));
	         }
	      });   

	      frame.getContentPane().add(new JScrollPane(list));
	      frame.pack();
	       frame.setVisible(true);
	}
	}
	class CheckListItem{
	   private String  label;
	   private boolean isSelected = false;

	   public CheckListItem(String label){
	      this.label = label;
	   }
	   public boolean isSelected(){
	      return isSelected;
	   }
	   public void setSelected(boolean isSelected){
	      this.isSelected = isSelected;
	   }
	   public String toString(){
	      return label;
	   }
	}
	class CheckListRenderer extends JCheckBox  implements ListCellRenderer{
	   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean hasFocus)
	   {
	      setEnabled(list.isEnabled());
	      setSelected(((CheckListItem)value).isSelected());
	      setFont(list.getFont());
	      setBackground(list.getBackground());
	      setForeground(list.getForeground());
	      setText(value.toString());
	      return this;
	   }
	}*/


