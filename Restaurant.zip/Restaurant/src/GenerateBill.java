import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.AbstractButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPCellEvent;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class GenerateBill implements ActionListener {
JFrame frame1;
private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 10,
        Font.BOLD);
private static Font catFont1 = new Font(Font.FontFamily.TIMES_ROMAN, 10,
        Font.BOLD);
	@Override
	public void actionPerformed(ActionEvent e) {
		 

		// TODO Auto-generated method stub
		Connection con=null;
		String id = null;
		try{
			 Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
			 System.out.println("SQLite3 Connection Established ...");
			 
			 if(e.getSource()==MakeOrder.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder.pay1.getText().equals("")||MakeOrder.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder.tot1.getText()+"',WAITER_NAME='"+MakeOrder.wtr1.getText()+"',GST='"+MakeOrder.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder.pay1.getText()+"',TABLE_NO='"+MakeOrder.tab_no+"',SGST='"+MakeOrder.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder.wtr1.getText()+"'");
     	     			MakeOrder.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 
			 if(e.getSource()==MakeOrder2.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder2.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder2.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder2.pay1.getText().equals("")||MakeOrder2.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder2.tot1.getText()+"',WAITER_NAME='"+MakeOrder2.wtr1.getText()+"',GST='"+MakeOrder2.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder2.pay1.getText()+"',TABLE_NO='"+MakeOrder2.tab_no+"',SGST='"+MakeOrder2.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder2.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder2.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder2.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder2.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder2.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder2.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder2.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder2.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder2.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder2.wtr1.getText()+"'");
     	     			MakeOrder2.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder3.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder3.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder3.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder3.pay1.getText().equals("")||MakeOrder3.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder3.tot1.getText()+"',WAITER_NAME='"+MakeOrder3.wtr1.getText()+"',GST='"+MakeOrder3.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder3.pay1.getText()+"',TABLE_NO='"+MakeOrder3.tab_no+"',SGST='"+MakeOrder3.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder3.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder3.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder3.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder3.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder3.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder3.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder3.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder3.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder3.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder3.wtr1.getText()+"'");
     	     			MakeOrder3.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 
			 if(e.getSource()==MakeOrder4.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder4.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder4.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder4.pay1.getText().equals("")||MakeOrder4.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder4.tot1.getText()+"',WAITER_NAME='"+MakeOrder4.wtr1.getText()+"',GST='"+MakeOrder4.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder4.pay1.getText()+"',TABLE_NO='"+MakeOrder4.tab_no+"',SGST='"+MakeOrder4.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder4.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder4.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder4.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder4.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder4.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder4.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder4.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder4.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder4.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder4.wtr1.getText()+"'");
     	     			MakeOrder4.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder5.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder5.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder5.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder5.pay1.getText().equals("")||MakeOrder5.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder5.tot1.getText()+"',WAITER_NAME='"+MakeOrder5.wtr1.getText()+"',GST='"+MakeOrder5.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder5.pay1.getText()+"',TABLE_NO='"+MakeOrder5.tab_no+"',SGST='"+MakeOrder5.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder5.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder5.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder5.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder5.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder5.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder5.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder5.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder5.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder5.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder5.wtr1.getText()+"'");
     	     			MakeOrder5.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder6.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder6.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder6.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder6.pay1.getText().equals("")||MakeOrder6.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder6.tot1.getText()+"',WAITER_NAME='"+MakeOrder6.wtr1.getText()+"',GST='"+MakeOrder6.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder6.pay1.getText()+"',TABLE_NO='"+MakeOrder6.tab_no+"',SGST='"+MakeOrder6.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder6.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder6.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder6.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder6.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder6.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder6.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder6.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder6.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder6.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder6.wtr1.getText()+"'");
     	     			MakeOrder6.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder7.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder7.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder7.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder7.pay1.getText().equals("")||MakeOrder7.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder7.tot1.getText()+"',WAITER_NAME='"+MakeOrder7.wtr1.getText()+"',GST='"+MakeOrder7.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder7.pay1.getText()+"',TABLE_NO='"+MakeOrder7.tab_no+"',SGST='"+MakeOrder7.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder7.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder7.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder7.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder7.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder7.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder7.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder7.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder7.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder7.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder7.wtr1.getText()+"'");
     	     			MakeOrder7.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder8.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder8.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder8.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder8.pay1.getText().equals("")||MakeOrder8.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder8.tot1.getText()+"',WAITER_NAME='"+MakeOrder8.wtr1.getText()+"',GST='"+MakeOrder8.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder8.pay1.getText()+"',TABLE_NO='"+MakeOrder8.tab_no+"',SGST='"+MakeOrder8.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder8.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder8.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder8.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder8.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder8.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder8.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder8.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder8.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder8.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder8.wtr1.getText()+"'");
     	     			MakeOrder8.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder9.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder9.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder9.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder9.pay1.getText().equals("")||MakeOrder9.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder9.tot1.getText()+"',WAITER_NAME='"+MakeOrder9.wtr1.getText()+"',GST='"+MakeOrder9.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder9.pay1.getText()+"',TABLE_NO='"+MakeOrder9.tab_no+"',SGST='"+MakeOrder9.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder9.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder9.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder9.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder9.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder9.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder9.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder9.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder9.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder9.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder9.wtr1.getText()+"'");
     	     			MakeOrder9.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder10.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder10.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder10.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder10.pay1.getText().equals("")||MakeOrder10.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder10.tot1.getText()+"',WAITER_NAME='"+MakeOrder10.wtr1.getText()+"',GST='"+MakeOrder10.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder10.pay1.getText()+"',TABLE_NO='"+MakeOrder10.tab_no+"',SGST='"+MakeOrder10.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder10.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder10.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder10.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder10.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder10.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder10.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder10.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder10.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder10.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder10.wtr1.getText()+"'");
     	     			MakeOrder10.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder11.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder11.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder11.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder11.pay1.getText().equals("")||MakeOrder11.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder11.tot1.getText()+"',WAITER_NAME='"+MakeOrder11.wtr1.getText()+"',GST='"+MakeOrder11.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder11.pay1.getText()+"',TABLE_NO='"+MakeOrder11.tab_no+"',SGST='"+MakeOrder11.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder11.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder11.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder11.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder11.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder11.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder11.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder11.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder11.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder11.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder11.wtr1.getText()+"'");
     	     			MakeOrder11.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder12.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder12.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder12.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder12.pay1.getText().equals("")||MakeOrder12.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder12.tot1.getText()+"',WAITER_NAME='"+MakeOrder12.wtr1.getText()+"',GST='"+MakeOrder12.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder12.pay1.getText()+"',TABLE_NO='"+MakeOrder12.tab_no+"',SGST='"+MakeOrder12.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder12.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder12.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder12.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder12.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder12.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder12.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder12.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder12.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder12.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder12.wtr1.getText()+"'");
     	     			MakeOrder12.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder13.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder13.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder13.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder13.pay1.getText().equals("")||MakeOrder13.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder13.tot1.getText()+"',WAITER_NAME='"+MakeOrder13.wtr1.getText()+"',GST='"+MakeOrder13.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder13.pay1.getText()+"',TABLE_NO='"+MakeOrder13.tab_no+"',SGST='"+MakeOrder13.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder13.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder13.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder13.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder13.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder13.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder13.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder13.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder13.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder13.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder13.wtr1.getText()+"'");
     	     			MakeOrder13.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder14.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder14.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder14.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder14.pay1.getText().equals("")||MakeOrder14.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder14.tot1.getText()+"',WAITER_NAME='"+MakeOrder14.wtr1.getText()+"',GST='"+MakeOrder14.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder14.pay1.getText()+"',TABLE_NO='"+MakeOrder14.tab_no+"',SGST='"+MakeOrder14.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder14.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder14.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder14.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder14.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder14.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder14.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder14.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder14.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder14.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder14.wtr1.getText()+"'");
     	     			MakeOrder14.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder15.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder15.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder15.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder15.pay1.getText().equals("")||MakeOrder15.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder15.tot1.getText()+"',WAITER_NAME='"+MakeOrder15.wtr1.getText()+"',GST='"+MakeOrder15.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder15.pay1.getText()+"',TABLE_NO='"+MakeOrder15.tab_no+"',SGST='"+MakeOrder15.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder15.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder15.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder15.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder15.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder15.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder15.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder15.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder15.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder15.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder15.wtr1.getText()+"'");
     	     			MakeOrder15.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder16.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder16.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder16.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder16.pay1.getText().equals("")||MakeOrder16.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder16.tot1.getText()+"',WAITER_NAME='"+MakeOrder16.wtr1.getText()+"',GST='"+MakeOrder16.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder16.pay1.getText()+"',TABLE_NO='"+MakeOrder16.tab_no+"',SGST='"+MakeOrder16.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder16.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder16.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder16.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder16.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder16.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder16.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder16.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder16.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder16.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder16.wtr1.getText()+"'");
     	     			MakeOrder16.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder17.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder17.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder17.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder17.pay1.getText().equals("")||MakeOrder17.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder17.tot1.getText()+"',WAITER_NAME='"+MakeOrder17.wtr1.getText()+"',GST='"+MakeOrder17.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder17.pay1.getText()+"',TABLE_NO='"+MakeOrder17.tab_no+"',SGST='"+MakeOrder17.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder17.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder17.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder17.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder17.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder17.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder17.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder17.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder17.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder17.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder17.wtr1.getText()+"'");
     	     			MakeOrder17.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder18.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder18.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder18.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder18.pay1.getText().equals("")||MakeOrder18.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder18.tot1.getText()+"',WAITER_NAME='"+MakeOrder18.wtr1.getText()+"',GST='"+MakeOrder18.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder18.pay1.getText()+"',TABLE_NO='"+MakeOrder18.tab_no+"',SGST='"+MakeOrder18.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder18.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder18.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder18.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder18.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder18.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder18.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder18.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder18.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder18.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder18.wtr1.getText()+"'");
     	     			MakeOrder18.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder19.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder19.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder19.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder19.pay1.getText().equals("")||MakeOrder19.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder19.tot1.getText()+"',WAITER_NAME='"+MakeOrder19.wtr1.getText()+"',GST='"+MakeOrder19.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder19.pay1.getText()+"',TABLE_NO='"+MakeOrder19.tab_no+"',SGST='"+MakeOrder19.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder19.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder19.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder19.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder19.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder19.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder19.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder19.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder19.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder19.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder19.wtr1.getText()+"'");
     	     			MakeOrder19.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder20.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder20.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder20.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder20.pay1.getText().equals("")||MakeOrder20.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder20.tot1.getText()+"',WAITER_NAME='"+MakeOrder20.wtr1.getText()+"',GST='"+MakeOrder20.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder20.pay1.getText()+"',TABLE_NO='"+MakeOrder20.tab_no+"',SGST='"+MakeOrder20.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder20.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder20.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder20.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder20.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder20.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder20.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder20.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder20.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder20.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder20.wtr1.getText()+"'");
     	     			MakeOrder20.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder21.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder21.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder21.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder21.pay1.getText().equals("")||MakeOrder21.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder21.tot1.getText()+"',WAITER_NAME='"+MakeOrder21.wtr1.getText()+"',GST='"+MakeOrder21.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder21.pay1.getText()+"',TABLE_NO='"+MakeOrder21.tab_no+"',SGST='"+MakeOrder21.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder21.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder21.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder21.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder21.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder21.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder21.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder21.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder21.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder21.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder21.wtr1.getText()+"'");
     	     			MakeOrder21.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder22.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder22.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder22.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder22.pay1.getText().equals("")||MakeOrder22.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder22.tot1.getText()+"',WAITER_NAME='"+MakeOrder22.wtr1.getText()+"',GST='"+MakeOrder22.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder22.pay1.getText()+"',TABLE_NO='"+MakeOrder22.tab_no+"',SGST='"+MakeOrder22.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder22.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder22.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder22.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder22.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder22.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder22.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder22.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder22.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder22.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder22.wtr1.getText()+"'");
     	     			MakeOrder22.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder23.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder23.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder23.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder23.pay1.getText().equals("")||MakeOrder23.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder23.tot1.getText()+"',WAITER_NAME='"+MakeOrder23.wtr1.getText()+"',GST='"+MakeOrder23.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder23.pay1.getText()+"',TABLE_NO='"+MakeOrder23.tab_no+"',SGST='"+MakeOrder23.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder23.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder23.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder23.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder23.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder23.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder23.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder23.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder23.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder23.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder23.wtr1.getText()+"'");
     	     			MakeOrder23.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder24.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder24.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder24.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder24.pay1.getText().equals("")||MakeOrder24.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder24.tot1.getText()+"',WAITER_NAME='"+MakeOrder24.wtr1.getText()+"',GST='"+MakeOrder24.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder24.pay1.getText()+"',TABLE_NO='"+MakeOrder24.tab_no+"',SGST='"+MakeOrder24.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder24.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder24.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder24.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder24.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder24.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder24.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder24.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder24.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder24.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder24.wtr1.getText()+"'");
     	     			MakeOrder24.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 

			 if(e.getSource()==MakeOrder25.bill){
				 Document document = new Document();
				 String order_id="",date_="";
				 ArrayList<String> dish=new ArrayList<String>();
       			ArrayList<String> qty=new ArrayList<String>();
       			ArrayList<String> rate=new ArrayList<String>();
			  if(MakeOrder25.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			  }else if(MakeOrder25.gst1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "GST% should not be empty ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else if(MakeOrder25.pay1.getText().equals("")||MakeOrder25.pay1.getText().equals("0")){
				  JOptionPane.showMessageDialog(null, "Payable Amount Invalid ", "Alert", JOptionPane.ERROR_MESSAGE);
			  }else{
				  //JOptionPane.showMessageDialog(null, "hello ", "Alert", JOptionPane.ERROR_MESSAGE);

				  Statement st=con.createStatement();
      			
     			 ResultSet result_set1=st.executeQuery("select ID from cust_order");
     			while(result_set1.next())
 		        {
     				 id=result_set1.getString(1);
				
 				
 					
 		        }
     			System.out.println("order="+id);
     				  Statement st1=con.createStatement();
     					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
     	     			int iii=st1.executeUpdate("update cust_order set TOTAL='"+MakeOrder25.tot1.getText()+"',WAITER_NAME='"+MakeOrder25.wtr1.getText()+"',GST='"+MakeOrder25.gst1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder25.pay1.getText()+"',TABLE_NO='"+MakeOrder25.tab_no+"',SGST='"+MakeOrder25.gsts.getText()+"'");
     	     			
     	     			Statement st3=con.createStatement();
    					 //update cust_order set GST='1',PAYABLE_AMOUNT='100' where ID=1
    	     			int i2=st1.executeUpdate("update analysis set WAITER_NAME='"+MakeOrder25.wtr1.getText()+"',PAYABLE_AMOUNT='"+MakeOrder25.pay1.getText()+"'");

	              		try{
	              			
	              			
	           			 Class.forName("org.sqlite.JDBC");
	           			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
	           			 System.out.println("SQLite3 Connection Established ...");
	           			 String query="select * from selected_dish where CUSTOMER_NAME='"+MakeOrder25.stockName1.getText()+"'";	           
	           			 Statement stmt=con.createStatement();	        	 			
	        			 ResultSet rs=stmt.executeQuery(query);
	        			
	        			while(rs.next())
		     		        {
	        				System.out.println("DATA ...");
	        				order_id=rs.getString("ID");
	        				
	        				date_=rs.getString("DATE_");
	        				System.out.println(rs.getString("DISH_NAME"));
	        				System.out.print(rs.getString("QUANTITY"));
	        				System.out.print(rs.getString("PRICE"));
	        				dish.add(rs.getString("DISH_NAME"));
	        				qty.add(rs.getString("QUANTITY"));
	        				rate.add(rs.getString("PRICE")); 
	        				
		     		        }
	              		}catch(Exception ex){
	            			ex.printStackTrace();
	            		}
    	     			 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("Bill.pdf"));
    	     			 document.open();
    	     			Paragraph preface = new Paragraph();
    	     			Paragraph preface1 = new Paragraph();
    	     			Paragraph preface2 = new Paragraph();
    	     			Paragraph preface3 = new Paragraph();
    	     	       
    	     	        preface.add(new Paragraph("SUKHDEV VAISHNO DHABA", catFont));
    	     	       preface.setAlignment(Paragraph.ALIGN_CENTER);
    	     	       preface1.add(new Paragraph("G.T. ROAD,MURTHAL,SONIPATH,HARYANA", catFont));
    	     	      preface1.setAlignment(Paragraph.ALIGN_CENTER);
    	     	      preface2.add(new Paragraph("PHONE NO:0130-2475585,8607100811", catFont));
    	     	     preface2.setAlignment(Paragraph.ALIGN_CENTER);
    	     	     preface3.add(new Paragraph("GSTIN:06ABIFS3901K1Z3", catFont));
    	     	    preface3.setAlignment(Paragraph.ALIGN_CENTER);
    	     	        document.add(preface);
    	     	       document.add(preface1);
    	     	      document.add(preface2);
    	     	     document.add(preface3);
    	     	    document.add( Chunk.NEWLINE );
    	     			 document.add(new Paragraph("                      CUSTOMER_NAME : "+MakeOrder25.stockName1.getText()+"                                                                           ORDER ID : "+order_id,catFont));
    	     			document.add(new Paragraph("                     DATE & TIME : "+Calendar.getInstance().getTime(),catFont));
    	     			 document.add( Chunk.NEWLINE );
    	     			 PdfPTable table=new PdfPTable(3);
    	     			table.getDefaultCell().setBorderWidth(0f);
    	     			 table.setWidthPercentage(80);
    	     			 table.setSpacingAfter(1f);
    	     			 table.setSpacingBefore(1f);
    	     			 float[] colWidth={1f,1f,1f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
    	     			 table.setWidths(colWidth);
    	     			
    	     			
    	     			 PdfPCell c2=new PdfPCell(new Paragraph("ITEM",catFont1));
    	     			 PdfPCell c3=new PdfPCell(new Paragraph("QTY",catFont1));
    	     			PdfPCell c4=new PdfPCell(new Paragraph("RATE",catFont1));
    	     			c2.setBorder(Rectangle.NO_BORDER);
    	     		    c2.setBorder(PdfPCell.NO_BORDER);
    	     		    c2.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c3.setBorder(Rectangle.NO_BORDER);
    	     			 c3.setBorder(PdfPCell.NO_BORDER);
     	     		    c3.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     		
    	     			c4.setBorder(Rectangle.NO_BORDER);
    	     			 c4.setBorder(PdfPCell.NO_BORDER);
     	     		    c4.setCellEvent(new DottedCell(PdfPCell.BOX));
    	     			

    	     			 table.addCell(c2);
    	     			 table.addCell(c3);
    	     			 table.addCell(c4);
    	     			
    	     			 int i=0;
    	     			 System.out.println(dish.addAll(dish));
    	     			 while(i!=rate.size()){
    	     				 System.out.println(i);
    	     				System.out.println(dish.size());
    	     				 PdfPCell cc2=new PdfPCell(new Paragraph(dish.get(i),catFont1));
    	     				 System.out.println("item "+dish.get(i));
        	     			 PdfPCell cc3=new PdfPCell(new Paragraph(qty.get(i),catFont1));
        	     			System.out.println("qty "+qty.get(i));
        	     			 PdfPCell cc4=new PdfPCell(new Paragraph(rate.get(i),catFont1));
        	     			System.out.println("rate "+rate.get(i));
        	     			 
        	     			cc2.setBorder(Rectangle.NO_BORDER);
        	     	
        	     			cc3.setBorder(Rectangle.NO_BORDER);
            	     			cc4.setBorder(Rectangle.NO_BORDER);
        	     		
        	     			
        	     			 table.addCell(cc2);
        	     			table.addCell(cc3);
        	     			table.addCell(cc4);
        	     		
        	     			i=i+1;
    	     			 }
    	     			PdfPCell empt4=new PdfPCell(new Paragraph(""));
   	     			 PdfPCell tot=new PdfPCell(new Paragraph("TOTAL : ",catFont1));
   	     			PdfPCell tot2=new PdfPCell(new Paragraph(MakeOrder25.tot1.getText(),catFont1));
   	     		empt4.setBorder(Rectangle.NO_BORDER);
     			
   	     		tot.setBorder(Rectangle.NO_BORDER);
     		
     			tot2.setBorder(Rectangle.NO_BORDER);
     			
   	     			 table.addCell(empt4);
   	     			 table.addCell(tot);
   	     			 table.addCell(tot2);
   	     			 
    	     			 PdfPCell empt1=new PdfPCell(new Paragraph(""));
    	     			 PdfPCell cgst=new PdfPCell(new Paragraph("CGST %: ",catFont1));
    	     			PdfPCell cgst2=new PdfPCell(new Paragraph(MakeOrder25.gst1.getText(),catFont1));
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     	
    	     			cgst.setBorder(Rectangle.NO_BORDER);
    	     		
    	     			cgst2.setBorder(Rectangle.NO_BORDER);
    	     			
    	     			 table.addCell(empt1);
    	     			 table.addCell(cgst);
    	     			 table.addCell(cgst2);
    	     			 
    	     			 PdfPCell empt2=new PdfPCell(new Paragraph(""));
    	     			PdfPCell sgst=new PdfPCell(new Paragraph("SGST %: ",catFont1));
    	     			 PdfPCell sgst2=new PdfPCell(new Paragraph(MakeOrder25.gsts.getText(),catFont1));
    	     			 
    	     			empt1.setBorder(Rectangle.NO_BORDER);
    	     			//empt1.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst.setBorder(Rectangle.NO_BORDER);
    	     			//sgst.setBackgroundColor(new BaseColor(255,255,45));
    	     			sgst2.setBorder(Rectangle.NO_BORDER);
    	     			//sgst2.setBackgroundColor(new BaseColor(255,255,45));
    	     			table.addCell(empt1);
   	     			 table.addCell(sgst);
   	     			 table.addCell(sgst2);
   	     			 
   	     		 PdfPCell empt3=new PdfPCell(new Paragraph(""));
   	     			PdfPCell pa=new PdfPCell(new Paragraph("PAYABLE AMOUNT : ",catFont1));
   	     		 PdfPCell pa2=new PdfPCell(new Paragraph(MakeOrder25.pay1.getText(),catFont1));
   	     		empt3.setBorder(Rectangle.NO_BORDER);
     			
     			pa.setBorder(Rectangle.NO_BORDER);
     			
     			pa2.setBorder(Rectangle.NO_BORDER);
     			
   	     		table.addCell(empt3);
	     			 table.addCell(pa);
	     			 table.addCell(pa2);
	     		
       	     			 document.add(table);
       	     			document.add( Chunk.NEWLINE );		 
       	     			Paragraph end = new Paragraph();
       	     	    end.add(new Paragraph("Thank You Visit Again", catFont));
       	     	  end.setAlignment(Paragraph.ALIGN_CENTER);
 	     	       document.add(end);
    	     			 document.close();
    	     			 writer.close();
    	     			 File myFile = new File( "Bill.pdf");
    	     		     Desktop.getDesktop().open(myFile);

    	     			new MainUI();
    	     			
    	     			 Statement st2=con.createStatement();
      	     			int iiii=st2.executeUpdate("delete from selected_dish where CUSTOMER_NAME='"+MakeOrder25.stockName1.getText()+"'");
      	     			
      	     			
     	     			 Statement st4=con.createStatement();
     	     			int n=st2.executeUpdate("delete from waiter where DISH_NAME='"+MakeOrder25.wtr1.getText()+"'");
     	     			MakeOrder25.frame1.dispose();
     	     			
     	     		
     	     			
			  }
			  
			 }
			 


			 



			  
		}catch(Exception ee){
			ee.printStackTrace();
		}
		
	}

}


class DottedCell implements PdfPCellEvent {
    private int border = 0;
    public DottedCell(int border) {
        this.border = border;
    }
    public void cellLayout(PdfPCell cell, Rectangle position,
        PdfContentByte[] canvases) {
        PdfContentByte canvas = canvases[PdfPTable.LINECANVAS];
        canvas.saveState();
        canvas.setLineDash(0, 4, 2);
        if ((border & PdfPCell.TOP) == PdfPCell.TOP) {
            canvas.moveTo(position.getRight(), position.getTop());
            canvas.lineTo(position.getLeft(), position.getTop());
        }
        if ((border & PdfPCell.BOTTOM) == PdfPCell.BOTTOM) {
            canvas.moveTo(position.getRight(), position.getBottom());
            canvas.lineTo(position.getLeft(), position.getBottom());
        }
        if ((border & PdfPCell.RIGHT) == PdfPCell.RIGHT) {
            canvas.moveTo(position.getRight(), position.getTop());
            canvas.lineTo(position.getRight(), position.getBottom());
        }
        if ((border & PdfPCell.LEFT) == PdfPCell.LEFT) {
            canvas.moveTo(position.getLeft(), position.getTop());
            canvas.lineTo(position.getLeft(), position.getBottom());
        }
        canvas.stroke();
        canvas.restoreState();
    }
}