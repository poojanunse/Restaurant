import java.awt.Dimension;

import javax.swing.JPanel;

class DrawingArea extends JPanel {

   private static final int PREF_W = 600;
   private static final int PREF_H = 400;

   public void setUp() {
      // TODO finish
   }

   @Override
   public Dimension getPreferredSize() {
      return new Dimension(PREF_W, PREF_H);
   }

}