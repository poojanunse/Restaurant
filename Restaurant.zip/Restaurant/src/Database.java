import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Database implements ActionListener {

	 Connection con=null;
	 static int ctr=1;
	@Override
	public void actionPerformed(ActionEvent e) {
		try{
			 Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
			 System.out.println("SQLite3 Connection Established ...");
			
			 /*Food Start*/if(e.getSource()==Food.btnsubmit){
				if(Food.stockName1.getText().equals("")){
					 JOptionPane.showMessageDialog(null, "Dish Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
				  }else if(Food.qty1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Price should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
				  }else{
					  PreparedStatement stmt=con.prepareStatement("insert into food(DISH_NAME,PRICE,DATE_) values(?,?,?)");  
					  stmt.setString(1,Food.stockName1.getText());//1 specifies the first parameter in the query  
					  stmt.setString(2,Food.qty1.getText());  
					  stmt.setString(3,Food.date1.getText());					    
					  int i=stmt.executeUpdate();  
					  JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }

			}/*Food End*/
			 
			 /*Waiter Start*/if(e.getSource()==WA.btnsubmit){
				 int val=0;
				 Connection co=null;
				 try{
				 Class.forName("org.sqlite.JDBC");
				  co=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
				Statement st=co.createStatement();
				ResultSet rs=st.executeQuery("select STATUS from wa where WAITER_NAME='"+WA.stockName1.getText()+"'");
				while(rs.next()){
					val=rs.getInt(1);
				}
				 }catch(Exception ex){
					 System.out.println(ex);
				 }finally{
				//st.close();
				//rs.close();
				co.close();
				 }
				 
					if(WA.stockName1.getText().equals("")){
						 JOptionPane.showMessageDialog(null, "Waiter Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
					  }else if(WA.qty1.getText().equals("")){
						  JOptionPane.showMessageDialog(null, "Addresss should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
					  }else if(WA.pp.getText().equals("")){
						  JOptionPane.showMessageDialog(null, "Phone Number should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
					  }else if(WA.table1.getItem(WA.table1.getSelectedIndex()).equals("")){
						  JOptionPane.showMessageDialog(null, "Table is not assigned", "Alert", JOptionPane.ERROR_MESSAGE);	
					  }else{
						  PreparedStatement stmt1=con.prepareStatement("insert into wa(WAITER_NAME,TABLE_NO,STATUS,DATE_) values(?,?,?,?)");  
						  stmt1.setString(1,WA.stockName1.getText());//1 specifies the first parameter in the query  
						  stmt1.setString(2,WA.table1.getItem(WA.table1.getSelectedIndex()));  
						  if(ctr>=1){
							  stmt1.setInt(3,ctr+val);
						  }else{
						  stmt1.setInt(3,1);
						  }
						  stmt1.setString(4,WA.date1.getText());	
						  
						  //stmt1.setString(3,WA.date1.getText());	
						 // stmt1.setString(4,WA.date1.getText());
						  int ii=stmt1.executeUpdate();  
						  
						  PreparedStatement stmt=con.prepareStatement("insert into waiter(DISH_NAME,PRICE,DATE_,PHONE,TABLE_NO,STATUS) values(?,?,?,?,?,?)");  
						  stmt.setString(1,WA.stockName1.getText());//1 specifies the first parameter in the query  
						  stmt.setString(2,WA.qty1.getText());  
						  stmt.setString(3,WA.date1.getText());	
						  stmt.setString(4,WA.pp.getText());
						  stmt.setString(5,"Table "+WA.table1.getItem(WA.table1.getSelectedIndex()));
						//  if(ctr>=1){
							//  stmt.setInt(6,ctr+val);
						  //}else{
						  stmt.setInt(6,1);
						 // }
						  int i=stmt.executeUpdate();  
						  JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
					  }

				}/*Waiter End*/
			 
			 
			 /*MakeOrder Add Start*/if(e.getSource()==MakeOrder.add){
				  if(MakeOrder.wtr1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
					  MakeOrder.frame1.dispose();
				  }else if(MakeOrder.stockName1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
				  }else if(MakeOrder.qty1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
				  }else if(MakeOrder.txtInput.getText() .equals("")){
					  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
				  }else{
				  
				  
						  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
						  stmt.setString(1,MakeOrder.txtInput.getText());//1 specifies the first parameter in the query  
						  stmt.setInt(2,MakeOrder.getInt(MakeOrder.pp));
						  stmt.setString(3,MakeOrder.stockName1.getText());
						  stmt.setString(4,MakeOrder.tab_no);
						  stmt.setString(5,MakeOrder.qty1.getText());
						  stmt.setString(6,MakeOrder.date1.getText());
						  stmt.setString(7,MakeOrder.wtr1.getText());
						  int i=stmt.executeUpdate();  
						  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
						 
						  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
						  stmt1.setString(2,MakeOrder.txtInput.getText());//1 specifies the first parameter in the query  
						  stmt1.setInt(3,MakeOrder.getInt(MakeOrder.pp));
						  stmt1.setString(1,MakeOrder.stockName1.getText());
		
						  stmt1.setString(4,MakeOrder.qty1.getText());
						  stmt1.setString(5,MakeOrder.date1.getText());
					
						  int ii=stmt1.executeUpdate();  
						  
						  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
						  stmt2.setString(2,MakeOrder.txtInput.getText());//1 specifies the first parameter in the query  
						  stmt2.setString(3,MakeOrder.date1.getText());
						  stmt2.setString(1,MakeOrder.stockName1.getText());
						  int iii=stmt2.executeUpdate();
						  MakeOrder.txtInput.setText("");
						  MakeOrder.pp.setText("");
						  MakeOrder.qty1.setText("");
				  }

				}/*MakeOrder Add End*/
			 
			 
			 /*MakeOrder Start*/if(e.getSource()==MakeOrder.btnsubmit){
				 if(MakeOrder.stockName1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
				  }else{
				 Statement st=con.createStatement();
				 int price_sum=0;
     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder.stockName1.getText()+"'");
					  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
					  while(result_set1.next())
	     		        {
      				price_sum=result_set1.getInt(1);
      				MakeOrder.tot1.setText(price_sum+"");
	     		        }
					  if(price_sum==0){
						  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
					  }
				  }
			 }/*MakeOrder Stop*/
			 
			 
			 
			 /*MakeOrder Add Start*/if(e.getSource()==MakeOrder2.add){
				  if(MakeOrder2.wtr1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
					  MakeOrder2.frame1.dispose();
				  }else if(MakeOrder2.stockName1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
				  }else if(MakeOrder2.qty1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
				  }else if(MakeOrder2.txtInput.getText() .equals("")){
					  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
				  }else{
				  
				  
						  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
						  stmt.setString(1,MakeOrder2.txtInput.getText());//1 specifies the first parameter in the query  
						  stmt.setInt(2,MakeOrder2.getInt(MakeOrder.pp));
						  stmt.setString(3,MakeOrder2.stockName1.getText());
						  stmt.setString(4,MakeOrder2.tab_no);
						  stmt.setString(5,MakeOrder2.qty1.getText());
						  stmt.setString(6,MakeOrder2.date1.getText());
						  stmt.setString(7,MakeOrder2.wtr1.getText());
						  int i=stmt.executeUpdate();  
						  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
						 
						  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
						  stmt1.setString(2,MakeOrder2.txtInput.getText());//1 specifies the first parameter in the query  
						  stmt1.setInt(3,MakeOrder2.getInt(MakeOrder.pp));
						  stmt1.setString(1,MakeOrder2.stockName1.getText());
		
						  stmt1.setString(4,MakeOrder2.qty1.getText());
						  stmt1.setString(5,MakeOrder2.date1.getText());
					
						  int ii=stmt1.executeUpdate();  
						  
						  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
						  stmt2.setString(2,MakeOrder2.txtInput.getText());//1 specifies the first parameter in the query  
						  stmt2.setString(3,MakeOrder2.date1.getText());
						  stmt2.setString(1,MakeOrder2.stockName1.getText());
						  int iii=stmt2.executeUpdate();
						  MakeOrder2.txtInput.setText("");
						  MakeOrder2.pp.setText("");
						  MakeOrder2.qty1.setText("");
				  }

				}/*MakeOrder Add End*/
			 
			 
			 /*MakeOrder Start*/if(e.getSource()==MakeOrder2.btnsubmit){
				 if(MakeOrder2.stockName1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
				  }else{
				 Statement st=con.createStatement();
				 int price_sum=0;
     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder2.stockName1.getText()+"'");
					  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
					  while(result_set1.next())
	     		        {
      				price_sum=result_set1.getInt(1);
      				MakeOrder2.tot1.setText(price_sum+"");
	     		        }
					  if(price_sum==0){
						  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
					  }
				  }
			 }/*MakeOrder Stop*/
			 
		

			  
			 			 /*MakeOrder4 Add Start*/if(e.getSource()==MakeOrder4.add){
			 				  if(MakeOrder4.wtr1.getText().equals("")){
			 					  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 					  MakeOrder4.frame1.dispose();
			 				  }else if(MakeOrder4.stockName1.getText().equals("")){
			 					  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 				  }else if(MakeOrder4.qty1.getText().equals("")){
			 					  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 				  }else if(MakeOrder4.txtInput.getText() .equals("")){
			 					  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 				  }else{
			 				  
			 				  
			 						  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 						  stmt.setString(1,MakeOrder4.txtInput.getText());//1 specifies the first parameter in the query  
			 						  stmt.setInt(2,MakeOrder4.getInt(MakeOrder4.pp));
			 						  stmt.setString(3,MakeOrder4.stockName1.getText());
			 						  stmt.setString(4,MakeOrder4.tab_no);
			 						  stmt.setString(5,MakeOrder4.qty1.getText());
			 						  stmt.setString(6,MakeOrder4.date1.getText());
			 						  stmt.setString(7,MakeOrder4.wtr1.getText());
			 						  int i=stmt.executeUpdate();  
			 						  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 						 
			 						  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 						  stmt1.setString(2,MakeOrder4.txtInput.getText());//1 specifies the first parameter in the query  
			 						  stmt1.setInt(3,MakeOrder4.getInt(MakeOrder4.pp));
			 						  stmt1.setString(1,MakeOrder4.stockName1.getText());
			 		
			 						  stmt1.setString(4,MakeOrder4.qty1.getText());
			 						  stmt1.setString(5,MakeOrder4.date1.getText());
			 					
			 						  int ii=stmt1.executeUpdate();  
			 						  
			 						  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 						  stmt2.setString(2,MakeOrder4.txtInput.getText());//1 specifies the first parameter in the query  
			 						  stmt2.setString(3,MakeOrder4.date1.getText());
			 						  stmt2.setString(1,MakeOrder4.stockName1.getText());
			 						  int iii=stmt2.executeUpdate();
			 						  MakeOrder4.txtInput.setText("");
			 						  MakeOrder4.pp.setText("");
			 						  MakeOrder4.qty1.setText("");
			 				  }

			 				}/*MakeOrder4 Add End*/
			 			 
			 			 
			 			 /*MakeOrder4 Start*/if(e.getSource()==MakeOrder4.btnsubmit){
			 				 if(MakeOrder4.stockName1.getText().equals("")){
			 					  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 				  }else{
			 				 Statement st=con.createStatement();
			 				 int price_sum=0;
			      			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder4.stockName1.getText()+"'");
			 					  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 					  while(result_set1.next())
			 	     		        {
			       				price_sum=result_set1.getInt(1);
			       				MakeOrder4.tot1.setText(price_sum+"");
			 	     		        }
			 					  if(price_sum==0){
			 						  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 					  }
			 				  }
			 			 }/*MakeOrder4 Stop*/
			 			 
			 			
			 			 
			 						 /*MakeOrder3 Add Start*/if(e.getSource()==MakeOrder3.add){
			 							  if(MakeOrder3.wtr1.getText().equals("")){
			 								  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 								  MakeOrder3.frame1.dispose();
			 							  }else if(MakeOrder3.stockName1.getText().equals("")){
			 								  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 							  }else if(MakeOrder3.qty1.getText().equals("")){
			 								  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 							  }else if(MakeOrder3.txtInput.getText() .equals("")){
			 								  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 							  }else{
			 							  
			 							  
			 									  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 									  stmt.setString(1,MakeOrder3.txtInput.getText());//1 specifies the first parameter in the query  
			 									  stmt.setInt(2,MakeOrder3.getInt(MakeOrder3.pp));
			 									  stmt.setString(3,MakeOrder3.stockName1.getText());
			 									  stmt.setString(4,MakeOrder3.tab_no);
			 									  stmt.setString(5,MakeOrder3.qty1.getText());
			 									  stmt.setString(6,MakeOrder3.date1.getText());
			 									 stmt.setString(7,MakeOrder3.wtr1.getText());
			 									  int i=stmt.executeUpdate();  
			 									  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 									 
			 									  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 									  stmt1.setString(2,MakeOrder3.txtInput.getText());//1 specifies the first parameter in the query  
			 									  stmt1.setInt(3,MakeOrder3.getInt(MakeOrder3.pp));
			 									  stmt1.setString(1,MakeOrder3.stockName1.getText());
			 					
			 									  stmt1.setString(4,MakeOrder3.qty1.getText());
			 									  stmt1.setString(5,MakeOrder3.date1.getText());
			 								
			 									  int ii=stmt1.executeUpdate();  
			 									  
			 									  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 									  stmt2.setString(2,MakeOrder3.txtInput.getText());//1 specifies the first parameter in the query  
			 									  stmt2.setString(3,MakeOrder3.date1.getText());
			 									  stmt2.setString(1,MakeOrder3.stockName1.getText());
			 									  int iii=stmt2.executeUpdate();
			 									  MakeOrder3.txtInput.setText("");
			 									  MakeOrder3.pp.setText("");
			 									  MakeOrder3.qty1.setText("");
			 							  }

			 							}/*MakeOrder3 Add End*/
			 						 
			 						 
			 						 /*MakeOrder3 Start*/if(e.getSource()==MakeOrder3.btnsubmit){
			 							 if(MakeOrder3.stockName1.getText().equals("")){
			 								  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 							  }else{
			 							 Statement st=con.createStatement();
			 							 int price_sum=0;
			 			     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder3.stockName1.getText()+"'");
			 								  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 								  while(result_set1.next())
			 				     		        {
			 			      				price_sum=result_set1.getInt(1);
			 			      				MakeOrder3.tot1.setText(price_sum+"");
			 				     		        }
			 								  if(price_sum==0){
			 									  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 								  }
			 							  }
			 						 }/*MakeOrder3 Stop*/
			 						 
			 						
			 						 
			 									 /*MakeOrder5 Add Start*/if(e.getSource()==MakeOrder5.add){
			 										  if(MakeOrder5.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder5.frame1.dispose();
			 										  }else if(MakeOrder5.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder5.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder5.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder5.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder5.getInt(MakeOrder5.pp));
			 												  stmt.setString(3,MakeOrder5.stockName1.getText());
			 												  stmt.setString(4,MakeOrder5.tab_no);
			 												  stmt.setString(5,MakeOrder5.qty1.getText());
			 												  stmt.setString(6,MakeOrder5.date1.getText());
			 												 stmt.setString(7,MakeOrder5.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder5.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder5.getInt(MakeOrder5.pp));
			 												  stmt1.setString(1,MakeOrder5.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder5.qty1.getText());
			 												  stmt1.setString(5,MakeOrder5.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder5.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder5.date1.getText());
			 												  stmt2.setString(1,MakeOrder5.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder5.txtInput.setText("");
			 												  MakeOrder5.pp.setText("");
			 												  MakeOrder5.qty1.setText("");
			 										  }

			 										}/*MakeOrder5 Add End*/
			 									 
			 									 
			 									 /*MakeOrder5 Start*/if(e.getSource()==MakeOrder5.btnsubmit){
			 										 if(MakeOrder5.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder5.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder5.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder5 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder6 Add Start*/if(e.getSource()==MakeOrder6.add){
			 										  if(MakeOrder6.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder6.frame1.dispose();
			 										  }else if(MakeOrder6.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder6.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder6.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder6.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder6.getInt(MakeOrder6.pp));
			 												  stmt.setString(3,MakeOrder6.stockName1.getText());
			 												  stmt.setString(4,MakeOrder6.tab_no);
			 												  stmt.setString(5,MakeOrder6.qty1.getText());
			 												  stmt.setString(6,MakeOrder6.date1.getText());
			 												 stmt.setString(7,MakeOrder6.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder6.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder6.getInt(MakeOrder6.pp));
			 												  stmt1.setString(1,MakeOrder6.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder6.qty1.getText());
			 												  stmt1.setString(5,MakeOrder6.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder6.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder6.date1.getText());
			 												  stmt2.setString(1,MakeOrder6.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder6.txtInput.setText("");
			 												  MakeOrder6.pp.setText("");
			 												  MakeOrder6.qty1.setText("");
			 										  }

			 										}/*MakeOrder6 Add End*/
			 									 
			 									 
			 									 /*MakeOrder6 Start*/if(e.getSource()==MakeOrder6.btnsubmit){
			 										 if(MakeOrder6.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder6.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder6.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder6 Stop*/
			 									 


			 									 
			 									 /*MakeOrder7 Add Start*/if(e.getSource()==MakeOrder7.add){
			 										  if(MakeOrder7.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder7.frame1.dispose();
			 										  }else if(MakeOrder7.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder7.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder7.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder7.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder7.getInt(MakeOrder7.pp));
			 												  stmt.setString(3,MakeOrder7.stockName1.getText());
			 												  stmt.setString(4,MakeOrder7.tab_no);
			 												  stmt.setString(5,MakeOrder7.qty1.getText());
			 												  stmt.setString(6,MakeOrder7.date1.getText());
			 												 stmt.setString(7,MakeOrder7.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder7.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder7.getInt(MakeOrder7.pp));
			 												  stmt1.setString(1,MakeOrder7.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder7.qty1.getText());
			 												  stmt1.setString(5,MakeOrder7.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder7.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder7.date1.getText());
			 												  stmt2.setString(1,MakeOrder7.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder7.txtInput.setText("");
			 												  MakeOrder7.pp.setText("");
			 												  MakeOrder7.qty1.setText("");
			 										  }

			 										}/*MakeOrder7 Add End*/
			 									 
			 									 
			 									 /*MakeOrder7 Start*/if(e.getSource()==MakeOrder7.btnsubmit){
			 										 if(MakeOrder7.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder7.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder7.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder7 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder8 Add Start*/if(e.getSource()==MakeOrder8.add){
			 										  if(MakeOrder8.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder8.frame1.dispose();
			 										  }else if(MakeOrder8.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder8.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder8.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder8.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder8.getInt(MakeOrder8.pp));
			 												  stmt.setString(3,MakeOrder8.stockName1.getText());
			 												  stmt.setString(4,MakeOrder8.tab_no);
			 												  stmt.setString(5,MakeOrder8.qty1.getText());
			 												  stmt.setString(6,MakeOrder8.date1.getText());
			 												 stmt.setString(7,MakeOrder8.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder8.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder8.getInt(MakeOrder8.pp));
			 												  stmt1.setString(1,MakeOrder8.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder8.qty1.getText());
			 												  stmt1.setString(5,MakeOrder8.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder8.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder8.date1.getText());
			 												  stmt2.setString(1,MakeOrder8.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder8.txtInput.setText("");
			 												  MakeOrder8.pp.setText("");
			 												  MakeOrder8.qty1.setText("");
			 										  }

			 										}/*MakeOrder8 Add End*/
			 									 
			 									 
			 									 /*MakeOrder8 Start*/if(e.getSource()==MakeOrder8.btnsubmit){
			 										 if(MakeOrder8.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder8.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder8.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder8 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder9 Add Start*/if(e.getSource()==MakeOrder9.add){
			 										  if(MakeOrder9.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder9.frame1.dispose();
			 										  }else if(MakeOrder9.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder9.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder9.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder9.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder9.getInt(MakeOrder9.pp));
			 												  stmt.setString(3,MakeOrder9.stockName1.getText());
			 												  stmt.setString(4,MakeOrder9.tab_no);
			 												  stmt.setString(5,MakeOrder9.qty1.getText());
			 												  stmt.setString(6,MakeOrder9.date1.getText());
			 												 stmt.setString(7,MakeOrder9.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder9.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder9.getInt(MakeOrder9.pp));
			 												  stmt1.setString(1,MakeOrder9.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder9.qty1.getText());
			 												  stmt1.setString(5,MakeOrder9.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder9.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder9.date1.getText());
			 												  stmt2.setString(1,MakeOrder9.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder9.txtInput.setText("");
			 												  MakeOrder9.pp.setText("");
			 												  MakeOrder9.qty1.setText("");
			 										  }

			 										}/*MakeOrder9 Add End*/
			 									 
			 									 
			 									 /*MakeOrder9 Start*/if(e.getSource()==MakeOrder9.btnsubmit){
			 										 if(MakeOrder9.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder9.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder9.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder9 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder10 Add Start*/if(e.getSource()==MakeOrder10.add){
			 										  if(MakeOrder10.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder10.frame1.dispose();
			 										  }else if(MakeOrder10.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder10.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder10.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder10.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder10.getInt(MakeOrder10.pp));
			 												  stmt.setString(3,MakeOrder10.stockName1.getText());
			 												  stmt.setString(4,MakeOrder10.tab_no);
			 												  stmt.setString(5,MakeOrder10.qty1.getText());
			 												  stmt.setString(6,MakeOrder10.date1.getText());
			 												 stmt.setString(7,MakeOrder10.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder10.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder10.getInt(MakeOrder10.pp));
			 												  stmt1.setString(1,MakeOrder10.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder10.qty1.getText());
			 												  stmt1.setString(5,MakeOrder10.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder10.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder10.date1.getText());
			 												  stmt2.setString(1,MakeOrder10.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder10.txtInput.setText("");
			 												  MakeOrder10.pp.setText("");
			 												  MakeOrder10.qty1.setText("");
			 										  }

			 										}/*MakeOrder10 Add End*/
			 									 
			 									 
			 									 /*MakeOrder10 Start*/if(e.getSource()==MakeOrder10.btnsubmit){
			 										 if(MakeOrder10.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder10.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder10.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder10 Stop*/
			 									 


			 									 
			 									 /*MakeOrder11 Add Start*/if(e.getSource()==MakeOrder11.add){
			 										  if(MakeOrder11.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder11.frame1.dispose();
			 										  }else if(MakeOrder11.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder11.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder11.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder11.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder11.getInt(MakeOrder11.pp));
			 												  stmt.setString(3,MakeOrder11.stockName1.getText());
			 												  stmt.setString(4,MakeOrder11.tab_no);
			 												  stmt.setString(5,MakeOrder11.qty1.getText());
			 												  stmt.setString(6,MakeOrder11.date1.getText());
			 												 stmt.setString(7,MakeOrder11.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder11.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder11.getInt(MakeOrder11.pp));
			 												  stmt1.setString(1,MakeOrder11.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder11.qty1.getText());
			 												  stmt1.setString(5,MakeOrder11.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder11.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder11.date1.getText());
			 												  stmt2.setString(1,MakeOrder11.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder11.txtInput.setText("");
			 												  MakeOrder11.pp.setText("");
			 												  MakeOrder11.qty1.setText("");
			 										  }

			 										}/*MakeOrder11 Add End*/
			 									 
			 									 
			 									 /*MakeOrder11 Start*/if(e.getSource()==MakeOrder11.btnsubmit){
			 										 if(MakeOrder11.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder11.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder11.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder11 Stop*/
			 									 


			 									 
			 									 /*MakeOrder12 Add Start*/if(e.getSource()==MakeOrder12.add){
			 										  if(MakeOrder12.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder12.frame1.dispose();
			 										  }else if(MakeOrder12.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder12.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder12.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder12.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder12.getInt(MakeOrder12.pp));
			 												  stmt.setString(3,MakeOrder12.stockName1.getText());
			 												  stmt.setString(4,MakeOrder12.tab_no);
			 												  stmt.setString(5,MakeOrder12.qty1.getText());
			 												  stmt.setString(6,MakeOrder12.date1.getText());
			 												 stmt.setString(7,MakeOrder12.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder12.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder12.getInt(MakeOrder12.pp));
			 												  stmt1.setString(1,MakeOrder12.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder12.qty1.getText());
			 												  stmt1.setString(5,MakeOrder12.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder12.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder12.date1.getText());
			 												  stmt2.setString(1,MakeOrder12.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder12.txtInput.setText("");
			 												  MakeOrder12.pp.setText("");
			 												  MakeOrder12.qty1.setText("");
			 										  }

			 										}/*MakeOrder12 Add End*/
			 									 
			 									 
			 									 /*MakeOrder12 Start*/if(e.getSource()==MakeOrder12.btnsubmit){
			 										 if(MakeOrder12.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder12.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder12.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder12 Stop*/
			 									 


			 									 
			 									 /*MakeOrder13 Add Start*/if(e.getSource()==MakeOrder13.add){
			 										  if(MakeOrder13.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder13.frame1.dispose();
			 										  }else if(MakeOrder13.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder13.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder13.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder13.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder13.getInt(MakeOrder13.pp));
			 												  stmt.setString(3,MakeOrder13.stockName1.getText());
			 												  stmt.setString(4,MakeOrder13.tab_no);
			 												  stmt.setString(5,MakeOrder13.qty1.getText());
			 												  stmt.setString(6,MakeOrder13.date1.getText());
			 												 stmt.setString(7,MakeOrder13.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder13.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder13.getInt(MakeOrder13.pp));
			 												  stmt1.setString(1,MakeOrder13.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder13.qty1.getText());
			 												  stmt1.setString(5,MakeOrder13.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder13.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder13.date1.getText());
			 												  stmt2.setString(1,MakeOrder13.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder13.txtInput.setText("");
			 												  MakeOrder13.pp.setText("");
			 												  MakeOrder13.qty1.setText("");
			 										  }

			 										}/*MakeOrder13 Add End*/
			 									 
			 									 
			 									 /*MakeOrder13 Start*/if(e.getSource()==MakeOrder13.btnsubmit){
			 										 if(MakeOrder13.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder13.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder13.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder13 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder14 Add Start*/if(e.getSource()==MakeOrder14.add){
			 										  if(MakeOrder14.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder14.frame1.dispose();
			 										  }else if(MakeOrder14.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder14.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder14.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder14.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder14.getInt(MakeOrder14.pp));
			 												  stmt.setString(3,MakeOrder14.stockName1.getText());
			 												  stmt.setString(4,MakeOrder14.tab_no);
			 												  stmt.setString(5,MakeOrder14.qty1.getText());
			 												  stmt.setString(6,MakeOrder14.date1.getText());
			 												 stmt.setString(7,MakeOrder14.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder14.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder14.getInt(MakeOrder14.pp));
			 												  stmt1.setString(1,MakeOrder14.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder14.qty1.getText());
			 												  stmt1.setString(5,MakeOrder14.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder14.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder14.date1.getText());
			 												  stmt2.setString(1,MakeOrder14.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder14.txtInput.setText("");
			 												  MakeOrder14.pp.setText("");
			 												  MakeOrder14.qty1.setText("");
			 										  }

			 										}/*MakeOrder14 Add End*/
			 									 
			 									 
			 									 /*MakeOrder14 Start*/if(e.getSource()==MakeOrder14.btnsubmit){
			 										 if(MakeOrder14.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder14.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder14.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder14 Stop*/
			 									 


			 									 
			 									 /*MakeOrder15 Add Start*/if(e.getSource()==MakeOrder15.add){
			 										  if(MakeOrder15.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder15.frame1.dispose();
			 										  }else if(MakeOrder15.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder15.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder15.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder15.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder15.getInt(MakeOrder15.pp));
			 												  stmt.setString(3,MakeOrder15.stockName1.getText());
			 												  stmt.setString(4,MakeOrder15.tab_no);
			 												  stmt.setString(5,MakeOrder15.qty1.getText());
			 												  stmt.setString(6,MakeOrder15.date1.getText());
			 												 stmt.setString(7,MakeOrder15.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder15.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder15.getInt(MakeOrder15.pp));
			 												  stmt1.setString(1,MakeOrder15.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder15.qty1.getText());
			 												  stmt1.setString(5,MakeOrder15.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder15.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder15.date1.getText());
			 												  stmt2.setString(1,MakeOrder15.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder15.txtInput.setText("");
			 												  MakeOrder15.pp.setText("");
			 												  MakeOrder15.qty1.setText("");
			 										  }

			 										}/*MakeOrder15 Add End*/
			 									 
			 									 
			 									 /*MakeOrder15 Start*/if(e.getSource()==MakeOrder15.btnsubmit){
			 										 if(MakeOrder15.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder15.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder15.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder15 Stop*/
			 									 


			 									 
			 									 /*MakeOrder16 Add Start*/if(e.getSource()==MakeOrder16.add){
			 										  if(MakeOrder16.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder16.frame1.dispose();
			 										  }else if(MakeOrder16.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder16.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder16.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder16.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder16.getInt(MakeOrder16.pp));
			 												  stmt.setString(3,MakeOrder16.stockName1.getText());
			 												  stmt.setString(4,MakeOrder16.tab_no);
			 												  stmt.setString(5,MakeOrder16.qty1.getText());
			 												  stmt.setString(6,MakeOrder16.date1.getText());
			 												 stmt.setString(7,MakeOrder16.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder16.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder16.getInt(MakeOrder16.pp));
			 												  stmt1.setString(1,MakeOrder16.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder16.qty1.getText());
			 												  stmt1.setString(5,MakeOrder16.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder16.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder16.date1.getText());
			 												  stmt2.setString(1,MakeOrder16.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder16.txtInput.setText("");
			 												  MakeOrder16.pp.setText("");
			 												  MakeOrder16.qty1.setText("");
			 										  }

			 										}/*MakeOrder16 Add End*/
			 									 
			 									 
			 									 /*MakeOrder16 Start*/if(e.getSource()==MakeOrder16.btnsubmit){
			 										 if(MakeOrder16.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder16.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder16.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder16 Stop*/
			 									 


			 									 
			 									 /*MakeOrder17 Add Start*/if(e.getSource()==MakeOrder17.add){
			 										  if(MakeOrder17.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder17.frame1.dispose();
			 										  }else if(MakeOrder17.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder17.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder17.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder17.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder17.getInt(MakeOrder17.pp));
			 												  stmt.setString(3,MakeOrder17.stockName1.getText());
			 												  stmt.setString(4,MakeOrder17.tab_no);
			 												  stmt.setString(5,MakeOrder17.qty1.getText());
			 												  stmt.setString(6,MakeOrder17.date1.getText());
			 												 stmt.setString(7,MakeOrder17.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder17.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder17.getInt(MakeOrder17.pp));
			 												  stmt1.setString(1,MakeOrder17.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder17.qty1.getText());
			 												  stmt1.setString(5,MakeOrder17.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder17.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder17.date1.getText());
			 												  stmt2.setString(1,MakeOrder17.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder17.txtInput.setText("");
			 												  MakeOrder17.pp.setText("");
			 												  MakeOrder17.qty1.setText("");
			 										  }

			 										}/*MakeOrder17 Add End*/
			 									 
			 									 
			 									 /*MakeOrder17 Start*/if(e.getSource()==MakeOrder17.btnsubmit){
			 										 if(MakeOrder17.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder17.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder17.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder17 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder18 Add Start*/if(e.getSource()==MakeOrder18.add){
			 										  if(MakeOrder18.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder18.frame1.dispose();
			 										  }else if(MakeOrder18.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder18.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder18.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder18.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder18.getInt(MakeOrder18.pp));
			 												  stmt.setString(3,MakeOrder18.stockName1.getText());
			 												  stmt.setString(4,MakeOrder18.tab_no);
			 												  stmt.setString(5,MakeOrder18.qty1.getText());
			 												  stmt.setString(6,MakeOrder18.date1.getText());
			 												 stmt.setString(7,MakeOrder18.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder18.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder18.getInt(MakeOrder18.pp));
			 												  stmt1.setString(1,MakeOrder18.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder18.qty1.getText());
			 												  stmt1.setString(5,MakeOrder18.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder18.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder18.date1.getText());
			 												  stmt2.setString(1,MakeOrder18.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder18.txtInput.setText("");
			 												  MakeOrder18.pp.setText("");
			 												  MakeOrder18.qty1.setText("");
			 										  }

			 										}/*MakeOrder18 Add End*/
			 									 
			 									 
			 									 /*MakeOrder18 Start*/if(e.getSource()==MakeOrder18.btnsubmit){
			 										 if(MakeOrder18.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder18.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder18.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder18 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder19 Add Start*/if(e.getSource()==MakeOrder19.add){
			 										  if(MakeOrder19.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder19.frame1.dispose();
			 										  }else if(MakeOrder19.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder19.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder19.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder19.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder19.getInt(MakeOrder19.pp));
			 												  stmt.setString(3,MakeOrder19.stockName1.getText());
			 												  stmt.setString(4,MakeOrder19.tab_no);
			 												  stmt.setString(5,MakeOrder19.qty1.getText());
			 												  stmt.setString(6,MakeOrder19.date1.getText());
			 												 stmt.setString(7,MakeOrder19.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder19.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder19.getInt(MakeOrder19.pp));
			 												  stmt1.setString(1,MakeOrder19.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder19.qty1.getText());
			 												  stmt1.setString(5,MakeOrder19.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder19.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder19.date1.getText());
			 												  stmt2.setString(1,MakeOrder19.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder19.txtInput.setText("");
			 												  MakeOrder19.pp.setText("");
			 												  MakeOrder19.qty1.setText("");
			 										  }

			 										}/*MakeOrder19 Add End*/
			 									 
			 									 
			 									 /*MakeOrder19 Start*/if(e.getSource()==MakeOrder19.btnsubmit){
			 										 if(MakeOrder19.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder19.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder19.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder19 Stop*/
			 									 


			 									 
			 									 /*MakeOrder20 Add Start*/if(e.getSource()==MakeOrder20.add){
			 										  if(MakeOrder20.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder20.frame1.dispose();
			 										  }else if(MakeOrder20.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder20.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder20.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder20.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder20.getInt(MakeOrder20.pp));
			 												  stmt.setString(3,MakeOrder20.stockName1.getText());
			 												  stmt.setString(4,MakeOrder20.tab_no);
			 												  stmt.setString(5,MakeOrder20.qty1.getText());
			 												  stmt.setString(6,MakeOrder20.date1.getText());
			 												 stmt.setString(7,MakeOrder20.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder20.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder20.getInt(MakeOrder20.pp));
			 												  stmt1.setString(1,MakeOrder20.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder20.qty1.getText());
			 												  stmt1.setString(5,MakeOrder20.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder20.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder20.date1.getText());
			 												  stmt2.setString(1,MakeOrder20.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder20.txtInput.setText("");
			 												  MakeOrder20.pp.setText("");
			 												  MakeOrder20.qty1.setText("");
			 										  }

			 										}/*MakeOrder20 Add End*/
			 									 
			 									 
			 									 /*MakeOrder20 Start*/if(e.getSource()==MakeOrder20.btnsubmit){
			 										 if(MakeOrder20.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder20.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder20.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder20 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder21 Add Start*/if(e.getSource()==MakeOrder21.add){
			 										  if(MakeOrder21.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder21.frame1.dispose();
			 										  }else if(MakeOrder21.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder21.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder21.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder21.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder21.getInt(MakeOrder21.pp));
			 												  stmt.setString(3,MakeOrder21.stockName1.getText());
			 												  stmt.setString(4,MakeOrder21.tab_no);
			 												  stmt.setString(5,MakeOrder21.qty1.getText());
			 												  stmt.setString(6,MakeOrder21.date1.getText());
			 												 stmt.setString(7,MakeOrder21.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder21.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder21.getInt(MakeOrder21.pp));
			 												  stmt1.setString(1,MakeOrder21.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder21.qty1.getText());
			 												  stmt1.setString(5,MakeOrder21.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder21.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder21.date1.getText());
			 												  stmt2.setString(1,MakeOrder21.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder21.txtInput.setText("");
			 												  MakeOrder21.pp.setText("");
			 												  MakeOrder21.qty1.setText("");
			 										  }

			 										}/*MakeOrder21 Add End*/
			 									 
			 									 
			 									 /*MakeOrder21 Start*/if(e.getSource()==MakeOrder21.btnsubmit){
			 										 if(MakeOrder21.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder21.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder21.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder21 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder22 Add Start*/if(e.getSource()==MakeOrder22.add){
			 										  if(MakeOrder22.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder22.frame1.dispose();
			 										  }else if(MakeOrder22.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder22.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder22.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder22.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder22.getInt(MakeOrder22.pp));
			 												  stmt.setString(3,MakeOrder22.stockName1.getText());
			 												  stmt.setString(4,MakeOrder22.tab_no);
			 												  stmt.setString(5,MakeOrder22.qty1.getText());
			 												  stmt.setString(6,MakeOrder22.date1.getText());
			 												 stmt.setString(7,MakeOrder22.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder22.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder22.getInt(MakeOrder22.pp));
			 												  stmt1.setString(1,MakeOrder22.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder22.qty1.getText());
			 												  stmt1.setString(5,MakeOrder22.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder22.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder22.date1.getText());
			 												  stmt2.setString(1,MakeOrder22.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder22.txtInput.setText("");
			 												  MakeOrder22.pp.setText("");
			 												  MakeOrder22.qty1.setText("");
			 										  }

			 										}/*MakeOrder22 Add End*/
			 									 
			 									 
			 									 /*MakeOrder22 Start*/if(e.getSource()==MakeOrder22.btnsubmit){
			 										 if(MakeOrder22.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder22.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder22.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder22 Stop*/
			 									 


			 									 
			 									 /*MakeOrder23 Add Start*/if(e.getSource()==MakeOrder23.add){
			 										  if(MakeOrder23.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder23.frame1.dispose();
			 										  }else if(MakeOrder23.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder23.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder23.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder23.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder23.getInt(MakeOrder23.pp));
			 												  stmt.setString(3,MakeOrder23.stockName1.getText());
			 												  stmt.setString(4,MakeOrder23.tab_no);
			 												  stmt.setString(5,MakeOrder23.qty1.getText());
			 												  stmt.setString(6,MakeOrder23.date1.getText());
			 												 stmt.setString(7,MakeOrder23.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder23.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder23.getInt(MakeOrder23.pp));
			 												  stmt1.setString(1,MakeOrder23.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder23.qty1.getText());
			 												  stmt1.setString(5,MakeOrder23.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder23.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder23.date1.getText());
			 												  stmt2.setString(1,MakeOrder23.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder23.txtInput.setText("");
			 												  MakeOrder23.pp.setText("");
			 												  MakeOrder23.qty1.setText("");
			 										  }

			 										}/*MakeOrder23 Add End*/
			 									 
			 									 
			 									 /*MakeOrder23 Start*/if(e.getSource()==MakeOrder23.btnsubmit){
			 										 if(MakeOrder23.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder23.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder23.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder23 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder24 Add Start*/if(e.getSource()==MakeOrder24.add){
			 										  if(MakeOrder24.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder24.frame1.dispose();
			 										  }else if(MakeOrder24.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder24.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder24.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder24.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder24.getInt(MakeOrder24.pp));
			 												  stmt.setString(3,MakeOrder24.stockName1.getText());
			 												  stmt.setString(4,MakeOrder24.tab_no);
			 												  stmt.setString(5,MakeOrder24.qty1.getText());
			 												  stmt.setString(6,MakeOrder24.date1.getText());
			 												 stmt.setString(7,MakeOrder24.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder24.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder24.getInt(MakeOrder24.pp));
			 												  stmt1.setString(1,MakeOrder24.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder24.qty1.getText());
			 												  stmt1.setString(5,MakeOrder24.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder24.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder24.date1.getText());
			 												  stmt2.setString(1,MakeOrder24.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder24.txtInput.setText("");
			 												  MakeOrder24.pp.setText("");
			 												  MakeOrder24.qty1.setText("");
			 										  }

			 										}/*MakeOrder24 Add End*/
			 									 
			 									 
			 									 /*MakeOrder24 Start*/if(e.getSource()==MakeOrder24.btnsubmit){
			 										 if(MakeOrder24.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder24.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder24.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder24 Stop*/
			 									 
			 									 


			 									 
			 									 /*MakeOrder25 Add Start*/if(e.getSource()==MakeOrder25.add){
			 										  if(MakeOrder25.wtr1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Assign Waiter", "Alert", JOptionPane.ERROR_MESSAGE);
			 											  MakeOrder25.frame1.dispose();
			 										  }else if(MakeOrder25.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else if(MakeOrder25.qty1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else if(MakeOrder25.txtInput.getText() .equals("")){
			 											  JOptionPane.showMessageDialog(null, "Please Select Dish ", "Alert", JOptionPane.ERROR_MESSAGE);
			 										  }else{
			 										  
			 										  
			 												  PreparedStatement stmt=con.prepareStatement("insert into selected_dish(DISH_NAME,PRICE,CUSTOMER_NAME,TABLE_NO,QUANTITY,DATE_,WAITER_NAME) values(?,?,?,?,?,?,?)");  
			 												  stmt.setString(1,MakeOrder25.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt.setInt(2,MakeOrder25.getInt(MakeOrder25.pp));
			 												  stmt.setString(3,MakeOrder25.stockName1.getText());
			 												  stmt.setString(4,MakeOrder25.tab_no);
			 												  stmt.setString(5,MakeOrder25.qty1.getText());
			 												  stmt.setString(6,MakeOrder25.date1.getText());
			 												 stmt.setString(7,MakeOrder25.wtr1.getText());
			 												  int i=stmt.executeUpdate();  
			 												  JOptionPane.showMessageDialog(null, "Dish Added", "Alert", JOptionPane.ERROR_MESSAGE);
			 												 
			 												  PreparedStatement stmt1=con.prepareStatement("insert into cust_order(CUSTOMER_NAME,DISH_NAME,PRICE,QUANTITY,DATE_) values(?,?,?,?,?)");  
			 												  stmt1.setString(2,MakeOrder25.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt1.setInt(3,MakeOrder25.getInt(MakeOrder25.pp));
			 												  stmt1.setString(1,MakeOrder25.stockName1.getText());
			 								
			 												  stmt1.setString(4,MakeOrder25.qty1.getText());
			 												  stmt1.setString(5,MakeOrder25.date1.getText());
			 											
			 												  int ii=stmt1.executeUpdate();  
			 												  
			 												  PreparedStatement stmt2=con.prepareStatement("insert into analysis(CUSTOMER_NAME,DISH_NAME,DATE_) values(?,?,?)");  
			 												  stmt2.setString(2,MakeOrder25.txtInput.getText());//1 specifies the first parameter in the query  
			 												  stmt2.setString(3,MakeOrder25.date1.getText());
			 												  stmt2.setString(1,MakeOrder25.stockName1.getText());
			 												  int iii=stmt2.executeUpdate();
			 												  MakeOrder25.txtInput.setText("");
			 												  MakeOrder25.pp.setText("");
			 												  MakeOrder25.qty1.setText("");
			 										  }

			 										}/*MakeOrder25 Add End*/
			 									 
			 									 
			 									 /*MakeOrder25 Start*/if(e.getSource()==MakeOrder25.btnsubmit){
			 										 if(MakeOrder25.stockName1.getText().equals("")){
			 											  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);	
			 										  }else{
			 										 Statement st=con.createStatement();
			 										 int price_sum=0;
			 						     			ResultSet result_set1=st.executeQuery("select SUM(price) from selected_dish where CUSTOMER_NAME='"+MakeOrder25.stockName1.getText()+"'");
			 											  //JOptionPane.showMessageDialog(null, "Record Inserted Successfully", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  while(result_set1.next())
			 							     		        {
			 						      				price_sum=result_set1.getInt(1);
			 						      				MakeOrder25.tot1.setText(price_sum+"");
			 							     		        }
			 											  if(price_sum==0){
			 												  JOptionPane.showMessageDialog(null, "Add Dish to Generate Total!!", "Alert", JOptionPane.ERROR_MESSAGE);  
			 											  }
			 										  }
			 									 }/*MakeOrder25 Stop*/
			 									 
			 
		}catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
		try {
			con.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		}
	}
	 static Integer getInt(JTextField gst12){
  	   Integer var;
  	   if(gst12.getText().trim().equals("")){
  		   var=0;
  	   }else{
  		   var=Integer.parseInt(gst12.getText());
  	   }
  	   return var;
     }
}
