import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date.*;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;


public class WA  implements ActionListener {
	static JButton btnsubmit,back;
	 static JTextField stockName1;
	 static Choice um1;
	 static JTextField pp;
	 static Choice table1;
	  static JTextArea qty1;
	  static JTextField date1;
	  static JFrame frame;
	  static JPanel panel,panel2;
	   JLabel status;
	   JLabel status1;
	   JLabel table;
	   ResultSet result_set=null;
	   String stock="",unit="",purchase_price="",quantity="";
	   static int waiter_cnt=0;
	   ArrayList<String> al1=new ArrayList<String>();
	 
	 public void actionPerformed(ActionEvent ae){
		
		frame=new JFrame();
		panel=new JPanel();
		
			frame.setVisible(true);
			 frame.setLayout(null);
			 frame.setSize(1500,1500);
			 frame.getContentPane().setBackground(Color.white);
			 frame.setTitle("Welcome to Inventory Management System");
			 
			 JLabel status1=new JLabel("Add Waiter");
			 status1.setBounds(100,40,250,60);
			
			 panel.add(status1);
			 
			 JLabel stockName=new JLabel("Waiter Name");
			 stockName.setBounds(70,90,90,60);
			 panel.add(stockName);
			
			 stockName1 =new JTextField();
			 stockName1.setBounds(250,100,150,20);
			 

			 panel.add(stockName1);
			  
			  JLabel qty=new JLabel("Address");
			  qty.setBounds(70,120,90,60);
			  panel.add(qty);
			  Border border = BorderFactory.createLineBorder(Color.BLACK);
				 //add1.setSize(400, 200);
				
			qty1 =new JTextArea();
			  qty1.setBounds(250,130,250,80);
			  qty1.setBorder(border);
			  panel.add(qty1);
			  
			  JLabel date=new JLabel("Date");
			  date.setBounds(70,220,90,60);
			  panel.add(date);
			  Calendar now = Calendar.getInstance();
	            int month = now.get(Calendar.MONTH);
	            int day = now.get(Calendar.DAY_OF_MONTH);
	            int year = now.get(Calendar.YEAR);
	            
	            
			 date1 =new JTextField();
			  date1.setBounds(250,230,90,20);
			 // date1.setText("" + (month + 1) + "/" + day + "/" + year);
			  date1.setText("" + year + "-" + (month+1) + "-" + day);
			  date1.setEditable(false);
			  panel.add(date1);
			  
			  JLabel status=new JLabel("Phone Number");
			  status.setBounds(70,260,90,60);
			  panel.add(status);
			pp =new JTextField();
			  pp.setBounds(250,270,90,20);
			  panel.add(pp);
			  
			  
			  try{
					Connection con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
					Statement s=con.createStatement();
					 ResultSet result_set1=s.executeQuery("select TABLE_NO from waiter where TABLE_NO!=''");
					 while(result_set1.next())
				        {
						 al1.add(result_set1.getString(1));	
						 System.out.println("=>"+result_set1.getString(1));
				        }
					}catch(Exception ee){
						System.out.println(ee);
					}
			 
			  
			  JLabel table=new JLabel("Assign Table");
			  table.setBounds(70,310,90,60);
			  panel.add(table);
			  table1=new Choice();
			  for(int i=1;i<=25;i++){
				  if(al1.contains("Table "+i)){
					//  i=i+1;
	                	 System.out.println("Table Matched");
	               // 	 JOptionPane.showMessageDialog(null, "Table is Busy Select Another one", "Alert", JOptionPane.ERROR_MESSAGE);
	                 }else{
				  table1.add(i+"");
	                 }
			  }
			  table1.setBounds(250,320,90,20);
			  panel.add(table1);
		
					           
					                 
					            
			
			 // table1 =new JTextField();
			 
			  
			
			  
			 btnsubmit=new JButton("SUBMIT");
			 Database db=new Database();
			  btnsubmit.setBounds(70,400,150,30);
			  btnsubmit.addActionListener(db);
			  
			
			  panel.add(btnsubmit);
			  
			  back=new JButton("BACK");
				 CLosePage p=new CLosePage();
				  back.setBounds(250,400,150,30);
				 
				  back.addActionListener(p);
				  panel.add(back);
				  
				  
			 /* System.out.println(AddStock.stockName1.getText());
			  System.out.println(AddStock.um1.getItem(um1.getSelectedIndex()));
			  System.out.println(AddStock.qty1.getText());
			  System.out.println(AddStock.pp.getText());
			  System.out.println(AddStock.date1.getText());*/
				  panel.setLayout(null);
				  panel.setBounds(30, 50, 500, 800);
				  
					panel2=new JPanel();
				  
					 Connection con=null;
					 String[] columnNames = {"ID","WAITERNAME","JOB_COUNT","TABLE_NO"};

					 
					 DefaultTableModel model = new DefaultTableModel();
						model.setColumnIdentifiers(columnNames);
					 JTable table1=new JTable();
					 table1.setModel(model);		
						table1.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
						table1.setFillsViewportHeight(true);
						table1.setBackground(Color.white);
						//table1.getColumnModel().getColumn(2).setPreferredWidth(10);
						//table1.getColumnModel().getColumn(3).setPreferredWidth(10);
						
						JScrollPane scroll = new JScrollPane(table1);
						scroll.setHorizontalScrollBarPolicy(
								JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
						scroll.setVerticalScrollBarPolicy(
								JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);		
									
						
					 try{
						 int i=0;
						  con=DriverManager.getConnection("jdbc:sqlite:sqlite/restaurant.db");
						 con.setAutoCommit(false);
						 System.out.println("SQLite3. Connection Established ...");
						
						 String query="select * from wa where STATUS=(select max(STATUS) from wa)";
						 Statement statement=con.createStatement();
						  result_set=statement.executeQuery(query);
						//ResultSetMetaData metadata=result_set.getMetaData();
						
						
						// JTable jt=new JTable(result_set[i],metadata[i]);  
						 String row[]={"ID","WAITERNAME","JOB_COUNT","TABLE_NO"};
						 
							while(result_set.next())
					        {
								stock=result_set.getString("ID");
								unit=result_set.getString("WAITER_NAME");
								purchase_price=result_set.getString("TABLE_NO");	
								waiter_cnt=result_set.getInt("STATUS");
								model.addRow(new Object[]{stock,unit,waiter_cnt,purchase_price});
								i++;				
					        }
							if(i <1)
							{
							//	JOptionPane.showMessageDialog(null, "No Record Found","Error",
								//		JOptionPane.ERROR_MESSAGE);
							}
							if(i ==1)
							{
							System.out.println(i+" Record Found");
							}
							else
							{
								System.out.println(i+" Records Found");
							}
							
						/*while(result_set.next())
						{
							stock=result_set.getString(1);
							unit=result_set.getString(2);
							purchase_price=result_set.getString(3);
							quantity=result_set.getString(4);
							date1=result_set.getString(5);
							String col[][]={{stock},{unit},{purchase_price},{quantity},{date1}};
							 
							
									
						}*/
					 }catch(Exception eee){
						 System.out.println(eee);
					 }finally{
						 try{
							 con.close();
						 }catch(Exception ee){
							 System.out.println(ee);
						 }
					 }
					 panel2.setBounds(600, 50, 800, 800);
							 panel2.add(scroll);

			  frame.add(panel);
			 
			  if(stock.equals(null)){
				  
			  }else{
			  frame.add(panel2);
			  }
}
}