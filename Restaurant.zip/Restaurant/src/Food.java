import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Food  implements ActionListener {
	static JButton btnsubmit,back;
	 static JTextField stockName1;
	 static Choice um1;
	 static JTextField pp;
	  static JTextField qty1;
	  static JTextField date1;
	  static JFrame frame;
	  static JLabel status;
	 
	
	 
	 public void actionPerformed(ActionEvent ae){
		
		frame=new JFrame();
			frame.setVisible(true);
			 frame.setLayout(null);
			 frame.setSize(1500,1500);
			 frame.getContentPane().setBackground(Color.white);
			 frame.setTitle("Welcome to Inventory Management System");
			
			 JLabel status1=new JLabel("Add Food");
			 status1.setBounds(100,40,250,60);
			
			 frame.add(status1);
			 
			 JLabel stockName=new JLabel("Dish Name");
			 stockName.setBounds(70,90,90,60);
			 frame.add(stockName);
			 stockName1 =new JTextField();
			 stockName1.setBounds(250,100,150,20);
			 frame.add(stockName1);
			  
			  JLabel qty=new JLabel("Price");
			  qty.setBounds(70,120,90,60);
			  frame.add(qty);
			qty1 =new JTextField();
			  qty1.setBounds(250,130,90,20);
			  frame.add(qty1);
			  
			  JLabel date=new JLabel("Date");
			  date.setBounds(70,150,90,60);
			  frame.add(date);
			  Calendar now = Calendar.getInstance();
	            int month = now.get(Calendar.MONTH);
	            int day = now.get(Calendar.DAY_OF_MONTH);
	            int year = now.get(Calendar.YEAR);
	            
			 date1 =new JTextField();
			  date1.setBounds(250,160,90,20);
			 // date1.setText("" + (month + 1) + "/" + day + "/" + year);
			  date1.setText("" + year + "-" + (month+1) + "-" + day);
			  date1.setEditable(false);
			  frame.add(date1);
			  
			 btnsubmit=new JButton("SUBMIT");
			 Database db=new Database();
			  btnsubmit.setBounds(70,200,150,30);
			  btnsubmit.addActionListener(db);
			  
			
			  frame.add(btnsubmit);
			  
			  back=new JButton("BACK");
				 CLosePage p=new CLosePage();
				  back.setBounds(250,200,150,30);
				
				  back.addActionListener(p);
				  frame.add(back);
				  
				
			 /* System.out.println(AddStock.stockName1.getText());
			  System.out.println(AddStock.um1.getItem(um1.getSelectedIndex()));
			  System.out.println(AddStock.qty1.getText());
			  System.out.println(AddStock.pp.getText());
			  System.out.println(AddStock.date1.getText());*/
			  
}
}